﻿#************************************************
# DC_KIR-RBC-RegEntries.ps1
# Version 1.0
# Date: 2020
# Author: + Walter Eder (waltere@microsoft.com)
# Description: Collects KIR (for 2019) and RBC (for 2016)  Registry Entries
# Called from: TS_AutoAddCommands_*.ps1
#*******************************************************

function InsertRegHeader(
	[string] $RegHeader="",
	[string]$OutputFile)
{
	if($RegHeader -ne "")
	{
		$RegHeader | Out-File -FilePath $OutputFile -Append -Encoding Default
		"=" * ($RegHeader.Length) | Out-File -FilePath $OutputFile -Append -Encoding Default
	}
}

Import-LocalizedData -BindingVariable InboxCommandStrings
	
Write-DiagProgress -Activity $InboxCommandStrings.ID_KIRRegentriesActivity -Status $InboxCommandStrings.ID_KIRRegentriesStatus

$OutputFile = $ComputerName + "_reg_KIR-RBC_MyKnobs.txt"
$fileDescription = "KIR (for 2019) and RBC (for 2016) Registry Entries"

InsertRegHeader -OutputFile $OutputFile -RegHeader "KIR (for 2019) Registry Entries"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Policies" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
