﻿#************************************************
# DC_CollectSqllogs.ps1
# Version 1.0.0
# Date: 10-2011
#
# Description: 
#			Collects SQL Server errorlogs and SQL Server Agent logs for all installed instances passed to script via the $Instances parameter
#			Can operate in "offline" mode where errorlog files are located using the registry or "online" mode
#			where errorlogs are enmerated and collected via xp_readerrorlog.
#
# Visibility:
#			Public - You should call this script to collect SQL Server errorlogs
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Script Parameters:
#			$Instances
#				Array of instances to collect errorlogs for
#           $CollectSqlErrorlogs
#               Switch parameter that indicates whether to collect SQL Server errorlogs 
#           $CollectSqlAgentLogs
#               Switch parameter that indicates whether to collect SQL Server Agent logs
#
# NOTE: This script expects the $Instances array to have been populated by the Enumerate-SqlInstances
#		function stored in "DSD\Scripts\SQL Server\Shared\Utilities\utils_DSD.ps1" and relies upon that format 
#       to function properly
#
# Author: Dan Shaver - dansha@microsoft.com
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Eliminated $Offline switch parameter as we no longer support "online" collection
#

# This script has dependencies on utils_CTS and utils_DSD
#
param( [Object[]] $instances, [switch]$CollectSqlErrorlogs, [switch] $CollectSqlAgentLogs) 

Import-LocalizedData -BindingVariable errorlogsCollectorStrings

#
# Function : Get-SqlAgentLogPath
# ----------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is used to find the path to the SQL Server errorlog for a given instance of SQL Server
# 
# Arguments:
#			$InstanceName
#			Function will find the path to the errorlogs for the instance passed 
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
function Get-SqlAgentLogPath([string]$SqlInstance)
{
	trap 
	{
		'[Get-SqlAgentLogPath] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}

    # Check if required parameter specified
	if ($null -ne $SqlInstance)
    {
        # Get instance folder name under SQL Root directory
        $InstanceKey = Get-SqlInstanceRootKey -SqlInstanceName $SqlInstance
    	
        if (($null -ne $InstanceKey) -and (0 -lt $InstanceKey.Length))
    	{
    		$SqlAgentKey = Join-Path -Path $InstanceKey -ChildPath '\SqlServerAgent'								
    								
    		# Test for valid Sql Agent registry key.  
    		if ($true -eq (Test-Path -Path $SqlAgentKey))
    		{	
                
                if ($false -eq (Test-RegistryValueIsNull -RegistryKey $SqlAgentKey -RegistryValueName 'ErrorLogFile'))
                {			
        			# Get the Sql Agent Errorlog path
        			$SqlAgentLogPath = [System.IO.Path]::GetDirectoryName((Get-ItemProperty -Path $SqlAgentKey).ErrorLogFile)
                                 
                    # Command Fail?
                    if ($false -eq $?)
                    {
                        "[Get-SqlAgentLogPath] : [ERROR] Failed to retrieve SQL Agent log path from [{0}\ErrorLogFile]" -f $SqlAgentKey | WriteTo-StdOut
                        Report-Error
                    }
                }
                else
                {
                    "[Get-SqlAgentLogPath] : [ERROR] Failed to retrieve SQL Agent log path from [{0}\ErrorLogFile] because the 'ErrorlogFile' registry value is null" -f $SqlAgentKey | WriteTo-StdOut
                }
    		}
    		else
    		{
    			# Report that we could not locate the SQL Agent log path
    			"[Get-SqlAgentLogPath] : Unable to locate SQL Agent log path for SQL Instance: [{0}]" -f $SqlInstance | WriteTo-StdOut
                "[Get-SqlAgentLogPath] : Registry key: [{0}] is invalid" -f $SqlAgentKey | WriteTo-StdOut
                Report-Error                            
    		}
            
    	} # if ($null -ne $InstanceKey)
    	else
    	{
    		"[Get-SqlAgentLogPath] : Failed to retrieve Instance Root key [{0}]" -f $InstanceKey | WriteTo-StdOut
    		Report-Error
    	}

    } # if ($null -eq $SqlInstance)
    else
    {
        '[Get-SqlAgentLogPath] : Required parameter: -SqlInstance was not specified' | WriteTo-StdOut
    }
    
	return $SqlAgentLogPath
}



#
# Function : Get-SqlAgentLogsOffline
# ----------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all Sql Agent logs for the instance passed to the function
#			This is an "offline" collector in that it does not rely on making a connection to the SQL Server instance to
#			find and collect the Sql Agent log files (via xp_readerrorlog). 
#			Finds the location of the Sql Agent logs from the registry and collects the files from the \log folder for the install
# 
# Arguments:
#			$InstanceName
#			Function will find the path to the Sql Agent errorlog for the instance passed 
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#

function Get-SqlAgentLogsOffline ([string]$InstanceToCollect )
{
	trap 
	{
		'[Get-SqlAgentLogsOffline] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error  
	}
	
    if ($null -ne $InstanceToCollect)
    {
        # Send a status message to stdout.log
    	"[Get-SqlAgentLogsOffline] : [INFO] Attempting to collect Sql Agent logs for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut

    	# Set the SectionDescription to the instance name that errorlogs were collected from
    	$SectionDescription = 'SQL Server Agent Logs for instance: ' + $InstanceToCollect

		# Get path to SQL Server Agent log files from registry
		$SqlAgentLogPath = Get-SqlAgentLogPath -SqlInstance $InstanceToCollect
    		
    	if (($null -ne $SqlAgentLogPath) -and (0 -lt $SqlAgentLogPath.Length))
    	{		
    		
            if ($true -eq (Test-Path -Path $SqlAgentLogPath))
    		{
            	
                # Enumerate and then copy the files
				$Files = @()
                $Files = Copy-FileSql -SourcePath $SqlAgentLogPath `
                         -FileFilters @('SQLAGENT.*') `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ERRORLOGS `
                         -InstanceName $InstanceToCollect `
						 -SectionDescription $SectionDescription `
						 -LCID (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect) `
						 -RenameCollectedFiles
                 
    			if (0 -eq $Files.Count)
    			{
                    #SQL Agent Log path is valid but no SQLAget log files exists ...
                    "[Get-SqlAgentLogsOffline] : [INFO] There are no Sql Agent log files for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
                }
    		} 
    		else 
    		# Invalid path to SQL Agent log files retrieved from registry.  
    		{
				# Does the log path reference a cluster disk that is offline from this node at this time?
                if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceToCollect -PathToTest $SqlAgentLogPath)) 
				{
    				# If above function returns true the drive is online but the path is bad
                    "[Get-SqlAgentLogsOffline] : [ERROR] Path to Sql Agent Log Files: [{0}] for instance: {1} is invalid" -f $SqlAgentLogPath, $InstanceToCollect | WriteTo-StdOut
                }              
    		}
    	} 
    	else 
    	{
    		"[Get-SqlAgentLogsOffline] : [ERROR] Could not locate errorlog path in the registry for instance: [{0}]. No Sql Agent log files will be collected. " -f $InstanceToCollect | WriteTo-StdOut
    	}
        
    } #if ($null -eq $InstanceToCollect)
    else
    {
        '[Get-SqlAgentLogsOffline] : [ERROR] Required parameter: -InstanceToCollect was not specified' | WriteTo-StdOut
    }
} 

#
# Function : Get-ErrorlogsOffline
# -------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all errorlogs for the instance passed to the function
#			This is an "offline" collector in that it does not rely on making a connection to the SQL Server instance to
#			find and collect the errorlog files. 
#			Finds the location of the errorlogs from the registry and collects the files from the \log folder for the install
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$IsClustered
#				This variable tells the collector whether to run an additional check if a drive appears offline preventing collection
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#

function Get-ErrorlogsOffline ([string]$InstanceToCollect)
{
	trap 
	{
		"[Get-ErrorlogsOffline] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error
	}
	
	if ($null -ne $InstanceToCollect)
    {
        # Write status message to stdout.log
        "[Get-ErrorlogsOffline] : [INFO] Attempting to collect errorlogs for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
    	
    	$SqlErrorLogPath = Get-SqlServerLogPath -SqlInstance $InstanceToCollect
    	
    	if ($null -ne $SqlErrorLogPath)
    	{		
    		if ( $true -eq (Test-Path -Path $SqlErrorLogPath) )
    		{
    			
                # Set the SectionDescription to the instance name that errorlogs were collected from
    			$SectionDescription = 'SQL Server Errorlogs for instance: ' + $InstanceToCollect 
             
                # Enumerate and then copy the files
				$Files = @()
				$Files = Copy-FileSql -SourcePath $SqlErrorLogPath `
                         -FileFilters @('ERRORLOG*') `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ERRORLOGS `
                         -InstanceName $InstanceToCollect `
						 -SectionDescription $SectionDescription `
						 -LCID (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect) `
						 -RenameCollectedFiles
                 
    			if (0 -eq $Files.Count)
    			{
                    "[Get-ErrorlogsOffline] : [INFO] There are no Sql errorlog files for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
                }
                
    		} # if ( $true -eq (Test-Path -Path $SqlErrorLogPath) )
    		# Errorlog path is invalid
    		else 
    		{
    			if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceToCollect -PathToTest $SqlErrorLogPath))
    	        {
    	            "[Get-ErrorlogsOffline] : [ERROR] No SQL errorlogs will be collected. Path to errorlogs: [{0}] for instance: {1} is invalid" -f $SqlErrorLogPath, $InstanceToCollect | WriteTo-StdOut
    	        }
    		}
    	}
    	# Couldn't locate errorlog path
    	else
    	{
    		"[Get-ErrorlogsOffline] : [ERROR] No SQL errorlogs will be collected. Could not locate the errorlog path in the registry for instance: {0} is invalid" -f $InstanceToCollect | WriteTo-StdOut
    	}
    } #if ($null -ne $InstanceToCollect)
    else
    {
        "[Get-ErrorlogsOffline] : [ERROR] Required parameter -InstanceToCollect was not specified" -f $InstanceToCollect | WriteTo-StdOut
    }
} 

#
# Function : Get-ErrorlogsOnline
# -------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all errorlogs for the instance passed to the function
#			This is an "online" collector that utilizes SQLCMD and xp_readerrorlog to collect the SQL Server errorlogs
#			This collector uses the same exact scrip that PSSDiag uses in order to maintain compatibility with any 
#			post-processing of errorlogs performed by SqlNexus
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
#function Get-ErrorlogsOnline ( [string]$InstanceName
#                             , [string]$NetName )
#{
#	trap 
#	
#		'[Get-ErrorlogsOnline] : Trapped error ...' | WriteTo-StdOut
#		Show-ErrorDetails -ErrorRecord $error[0] 
#
#		# Now clear all errors since we reported them
#		$Error.Clear() 
#	}
#	
#	New-Variable ERRORLOG_COLLECTOR_SCRIPT -Value 'collecterrorlog.sql' -Option ReadOnly
#	
#	if (('DEFAULT' -eq $InstanceName) -or ( 'MSSQLSERVER' -eq $InstanceName))
#	{
#		$ConnectToName = $NetName
#		$ErrorlogOutFileName = "{0}__SQL_Base_Errorlog_Shutdown.out" -f $NetName
#	} else {
#		$ConnectToName = $NetName+'\'+$InstanceName
#		$ErrorlogOutFileName = "{0}_{1}_SQL_Base_Errorlog_Shutdown.out" -f $NetName, $InstanceName
#	}
#
#	Execute-SqlScript -ConnectToName $ConnectToName `
#                     -ScriptToExecute $ERRORLOG_COLLECTOR_SCRIPT `
#                      -OutputFileName $ErrorlogOutFileName `
#                      -SectionDescription ("SQL Server Errorlogs for instance: {0}" -f $ConnectToName) `
#                      -FileDescription 'ERRORLOGS'
#}

#
# Function : Get-SqlErrorlogs
# ------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that calls Get-ErrorlogsOffline
#           This script used to support online and offline collection modes 
#           The "online" collector utilized SQLCMD and xp_readerrorlog to collect the SQL Server errorlogs
#			However, xp_readerrorlog wraps lines and this caused issues for loading the files in UDE so we no longer collect in this format
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
#

function Get-SqlErrorLogs ([object]$Instance)
{
	trap 
	{
		# Handle and report any exceptions that occur in this function, and then allow execution to resume 
		# Since this is only a wrapper function and doesn't do much to setup the excution of Get-ErrorlogsOffline, 
		# the called function may still succeed
		#
		'[Get-SqlErrorLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error
	}
	
    # Check if required parameter was passed
    if ($null -ne $Instance)
    {
       	# Update msdt dialog with progress message
    	Write-DiagProgress -Activity $errorlogsCollectorStrings.ID_SQL_CollectSqlErrorlogs -Status ($errorlogsCollectorStrings.ID_SQL_CollectSqlErrorlogsDesc + ": " + $instance.InstanceName)
    	
        if ($null -ne $Instance.InstanceName)
        {
        	"[Get-SqlErrorLogs] : [INFO] Collecting logs for instance {0}" -f $Instance.InstanceName | WriteTo-StdOut
        	Get-ErrorlogsOffline -InstanceToCollect $Instance.InstanceName 	
        }
        else
        {
            '[Get-SqlErrorLogs] : [ERROR] Passed instance name ($Instance.InstanceName) is null' | WriteTo-StdOut
        }
	}
    else
    {
        if ($null -eq $Instance)
        {
            '[Get-SqlErrorLogs] : [ERROR] Required parameter: -Instance was not specified' | WriteTo-StdOut
        }
    }	
	
}

#
# Function : Get-SqlAgentLogs
# ------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that calls Get-SqlAgentLogsOffline
#			Wrapper exists in case we want to add offline and online (via xp_readerrorlog) collection modes.  This is the function
#			
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
#
function Get-SqlAgentLogs ([object]$Instance)
{
	trap 
	{
		'[Get-SqlAgentLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}
	
	# Update msdt dialog with progress message
	Write-DiagProgress -Activity $errorlogsCollectorStrings.ID_SQL_CollectSqlAgentlogs -Status ($errorlogsCollectorStrings.ID_SQL_CollectSqlAgentlogsDesc + ": " + $instance.InstanceName)
	
    # Check if required parameter specified
    if ($null -ne $Instance)
    {
        # Write to debug log
    	"[Get-SqlAgentLogs] : [INFO] Collecting Sql Agent logs for instance {0}" -f $Instance.InstanceName | WriteTo-StdOut
    	Get-SqlAgentLogsOffline -InstanceToCollect $Instance.InstanceName 
    }
    else
    {
        '[Get-SqlAgentLogs] : [ERROR] Required parameter -Instance was not specified' | WriteTo-StdOut
    }
}

# Clear errors at entry to script
#
$Error.Clear()           
trap 
{
	'[DC-CollectSqllogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
	Report-Error 
}

if ($true -eq $global:SQL:debug)
{
    $CollectSqlErrorlogs=$true
    $CollectSqlAgentLogs=$true
}

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if ($true -eq (Check-SqlServerIsInstalled))
{
	# If $instance is null, get errorlogs for all instances installed on machine
	#

	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}
	
	if ($null -ne $instances)
    {
    
		foreach ($instance in $instances)
		{
			if ('DEFAULT' -eq $instance.InstanceName) {$instance.InstanceName='MSSQLSERVER'}
        
			if ($true -eq $CollectSqlErrorlogs)
			{
				Get-SqlErrorlogs -Instance $instance
			}
            
			if ($true -eq $CollectSqlAgentLogs)
			{
				Get-SqlAgentLogs -Instance $instance
			}
            
		}
        
	} # if ($null -ne $instances)
    else
    {
        "[DC_CollectSqllogs] : [WARN] No sql server instances were found on: [{0}] yet SQL Server appears to be installed" -f $ComputerName | WriteTo-StdOut 
    }
} # if ($true -eq (Check-SqlServerIsInstalled))

else 
{
    "[DC_CollectSqllogs] : No sql server instances are installed on: [{0}]" -f $ComputerName | WriteTo-StdOut 
}
	
# SIG # Begin signature block
# MIIa+AYJKoZIhvcNAQcCoIIa6TCCGuUCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU4qxejnwt6BARmStvZG8afJVM
# NqagghWCMIIEwzCCA6ugAwIBAgITMwAAADQkMUDJoMF5jQAAAAAANDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTMwMzI3MjAwODI1
# WhcNMTQwNjI3MjAwODI1WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkI4RUMtMzBBNC03MTQ0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5RoHrQqWLNS2
# NGTLNCDyvARYgou1CdxS1HCf4lws5/VqpPW2LrGBhlkB7ElsKQQe9TiLVxj1wDIN
# 7TSQ7MZF5buKCiWq76F7h9jxcGdKzWrc5q8FkT3tBXDrQc+rsSVmu6uitxj5eBN4
# dc2LM1x97WfE7QP9KKxYYMF7vYCNM5NhYgixj1ESZY9BfsTVJektZkHTQzT6l4H4
# /Ieh7TlSH/jpPv9egMkGNgfb27lqxzfPhrUaS0rUJfLHyI2vYWeK2lMv80wegyxj
# yqAQUhG6gVhzQoTjNLLu6pO+TILQfZYLT38vzxBdGkVmqwLxXyQARsHBVdKDckIi
# hjqkvpNQAQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFF9LQt4MuTig1GY2jVb7dFlJ
# ZoErMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAA9CUKDVHq0XPx8Kpis3imdYLbEwTzvvwldp7GXTTMVQcvJz
# JfbkhALFdRxxWEOr8cmqjt/Kb1g8iecvzXo17GbX1V66jp9XhpQQoOtRN61X9id7
# I08Z2OBtdgQlMGESraWOoya2SOVT8kVOxbiJJxCdqePPI+l5bK6TaDoa8xPEFLZ6
# Op5B2plWntDT4BaWkHJMrwH3JAb7GSuYslXMep/okjprMXuA8w6eV4u35gW2OSWa
# l4IpNos4rq6LGqzu5+wuv0supQc1gfMTIOq0SpOev5yDVn+tFS9cKXELlGc4/DC/
# Zef1Od7qIu2HjKuyO7UBwq3g/I4lFQwivp8M7R0wggTsMIID1KADAgECAhMzAAAA
# sBGvCovQO5/dAAEAAACwMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTEzMDEyNDIyMzMzOVoXDTE0MDQyNDIyMzMzOVowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOivXKIgDfgofLwFe3+t7ut2rChTPzrbQH2zjjPmVz+l
# URU0VKXPtIupP6g34S1Q7TUWTu9NetsTdoiwLPBZXKnr4dcpdeQbhSeb8/gtnkE2
# KwtA+747urlcdZMWUkvKM8U3sPPrfqj1QRVcCGUdITfwLLoiCxCxEJ13IoWEfE+5
# G5Cw9aP+i/QMmk6g9ckKIeKq4wE2R/0vgmqBA/WpNdyUV537S9QOgts4jxL+49Z6
# dIhk4WLEJS4qrp0YHw4etsKvJLQOULzeHJNcSaZ5tbbbzvlweygBhLgqKc+/qQUF
# 4eAPcU39rVwjgynrx8VKyOgnhNN+xkMLlQAFsU9lccUCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBRZcaZaM03amAeA/4Qevof5cjJB
# 8jBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# NGZhZjBiNzEtYWQzNy00YWEzLWE2NzEtNzZiYzA1MjM0NGFkMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQAx124qElczgdWdxuv5OtRETQie
# 7l7falu3ec8CnLx2aJ6QoZwLw3+ijPFNupU5+w3g4Zv0XSQPG42IFTp8263Os8ls
# ujksRX0kEVQmMA0N/0fqAwfl5GZdLHudHakQ+hywdPJPaWueqSSE2u2WoN9zpO9q
# GqxLYp7xfMAUf0jNTbJE+fA8k21C2Oh85hegm2hoCSj5ApfvEQO6Z1Ktwemzc6bS
# Y81K4j7k8079/6HguwITO10g3lU/o66QQDE4dSheBKlGbeb1enlAvR/N6EXVruJd
# PvV1x+ZmY2DM1ZqEh40kMPfvNNBjHbFCZ0oOS786Du+2lTqnOOQlkgimiGaCMIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBOAwggTc
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAsBGvCovQO5/d
# AAEAAACwMAkGBSsOAwIaBQCggfkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFH5r
# PVuF7wRWxvro5ngDniGCNarRMIGYBgorBgEEAYI3AgEMMYGJMIGGoGyAagBEAEkA
# QQBHAF8AQwBUAFMAXwBHAGUAbgBlAHIAYQBsAF8AUgBlAHAAbwByAHQAcwBfAGcA
# bABvAGIAYQBsAF8ARABDAF8AQwBvAGwAbABlAGMAdABTAHEAbABMAG8AZwBzAC4A
# cABzADGhFoAUaHR0cDovL21pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEA
# ckvs8Um6LrLYXMcn/hHSE1zB9qRyeLuvZfs6LISh4/YtGBXND25S0jbbGEEJ2mh7
# UB0eW0VrtiQCA2u9hLANWKnA9xhULWFW1mXZXgdZAgnZUdCMVCwnQSd32s19rCLM
# /lFL4wtyzerg/VyeF70rdSQK3f1v5kmd0byLe6qW2mfQI2HNGPulI258cSaWP/zH
# OTcMEwugoziMaWa9vVBjEAHIRtTZ88NkmGBaVQ3H+CaAOA2kIHnj1MVSJvkDOv3U
# 7Z1x4MfOujNQElydkr1BWYAPpbMHF+Z0P+sAXJGvMdmTRkS0FR7rkJAX50surr0B
# glc7ccg3VWrMeDMsMxKkcaGCAigwggIkBgkqhkiG9w0BCQYxggIVMIICEQIBATCB
# jjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQD
# ExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0ECEzMAAAA0JDFAyaDBeY0AAAAAADQw
# CQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcN
# AQkFMQ8XDTE0MDIyNDE3Mzc1NVowIwYJKoZIhvcNAQkEMRYEFPvSbtviA6Zlt296
# 7ft/NzjcNz+nMA0GCSqGSIb3DQEBBQUABIIBAKcSRKkHqxEC1z0XY6nn0BNRKW9a
# oMkTf84IlMOenSAHQ9Qrdur2ooy4WP+PA+h9/3uu4mPGn7SPVzqQ4BlcowQ1sIrt
# FNFFrgMSnbY1lwjG54lprE1W9OY3ofZdtFfj/Vg3dKjZ/8S5Slr1mRfQWlH0piio
# EVUi9nYvW6uZcED90wKQd8kKmhQk5BlK8h6hagleUhSgH2O21fuwGsSgL7n/F8ZY
# gxzAXYl+wkzoHN1NdvSNyFH3LgyGsyszoE61HkPCgjWVHZZhleLK8ytTxzo3aGx+
# MMyYTTbe/4FqVUUnGSH3h1pFVzmW2NzlKhXUr3Re/m/mvFbtJd0lBdC41OQ=
# SIG # End signature block
