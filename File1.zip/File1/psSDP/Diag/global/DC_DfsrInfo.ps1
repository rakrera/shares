﻿#************************************************
# DC_DfsrInfo.ps1
# Version 1.2.0
# Date: 4/19/2010
# By Craig Landis (clandis@microsoft.com)
#************************************************
# 2019-03-17 WalterE added Trap #_# nneds check for DFSrDiag.exe / OSversion?

function MenuDiagInput-CollectDFSR

{
    Write-Host -ForegroundColor Yellow 	"============AD Collect DFSR Information =============="
    Write-Host "1: Collect All"
    Write-Host "2: Collect All But Health-Reports"
    Write-Host "3: Collect Minimal"
	Write-Host "q: Press Q  or Enter to skip"
}

If ((get-wmiobject -query "Select ProductType from Win32_OperatingSystem").ProductType -ne 1) {

	$DFSRkey = "HKLM:\SYSTEM\CurrentControlSet\Services\DFSR"
            
	If (Test-Path $DFSRkey) { 

		Import-LocalizedData -BindingVariable DfsrInfoStrings -FileName DC_DfsrInfo -UICulture en-us
			
		Write-DiagProgress -Activity $DfsrInfoStrings.ID_DfsrInfo -Status $DfsrInfoStrings.ID_DfsrInfoObtaining

		$sectionDescription = "DFSR Miscellaneous"

		$OutputFile = "DFSR__Progress.txt"

		#_#$CollectDFSRInformation_Answer = get-diaginput -id "CollectDFSRInformation"
		MenuDiagInput-CollectDFSR
        $Selection = Read-Host "Choose the DFSR Information level"
		WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): DFSR Selection: $Selection" -shortformat
		switch ($Selection)
		{
			1 {$CommandToExecute = "cscript.exe DfsrInfo.vbs /msdt"}
			2 {$CommandToExecute = "cscript.exe DfsrInfo.vbs /msdt /noreports"}
			3 {$CommandToExecute = "cscript.exe DfsrInfo.vbs /msdt /noreports /nodbguids /nodebuglogs"}
			'q' {}
		}
		<#
		switch ($CollectDFSRInformation_Answer) 
				{
					"CollectAll" 
					{
						$CommandToExecute = "cscript.exe DfsrInfo.vbs /msdt"
					}
					"CollectAllButHealthReports" 
					{
						$CommandToExecute = "cscript.exe DfsrInfo.vbs /msdt /noreports"
					}
					"CollectMinimal" 
					{
						$CommandToExecute = "cscript.exe DfsrInfo.vbs /msdt /noreports /nodbguids /nodebuglogs"
					}
				}
		#>

		RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription "Progress Log"

		CollectFiles -filesToCollect "Dfsr*.log" -fileDescription "DFSR Current Log File" -sectionDescription "DFSR Debug Log Files" -renameOutput $false
		CollectFiles -filesToCollect "Dfsr*.gz" -fileDescription "DFSR Previous Log file" -sectionDescription "DFSR Debug Log Files" -renameOutput $false
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_ConflictAndDeleted.xls") -fileDescription "DFSR Conflicts and Deletes" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_Events_Last_72_Hours.xls") -fileDescription "DFSR Events Last 3 Days" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_File_Versions.txt") -fileDescription "DFSR File Versions" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_Hotfixes.txt") -fileDescription "DFSR Hotfixes" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_Info.txt") -fileDescription "DFSR Configuration Information" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_Performance_Data.txt") -fileDescription "DFSR Performance Data" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_DBGUIDs.txt") -fileDescription "DFSR Database GUIDs" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_DfsrMachineConfig.XML") -fileDescription "XML File" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_RegKey_DFSR.txt") -fileDescription "DFSR Registry Key" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_RegKey_TCPIP.txt") -fileDescription "TCPIP Registry Key" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_Replica*.xml") -fileDescription "XML File" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_Volume*.xml") -fileDescription "XML File" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_Dfsmgmt*.log") -fileDescription "DFS Management Trace Log" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_FSRM_File_Screens.txt") -fileDescription "FSRM File Screens" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect ($ComputerName + "_DFSR_FSRM_Quotas.txt") -fileDescription "FSRM Quotas" -sectionDescription "DFSR Miscellaneous"
		CollectFiles -filesToCollect "*HealthReport*" -fileDescription "Health Report" -sectionDescription "DFSR Health Reports"

	}
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}


