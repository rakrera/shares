﻿#************************************************
# DC_RAS-Component.ps1
# Version 1.0
#   Collects registry and netsh information.
# Version 1.1
#   Commented out "ras show activeservers". <- On Win7, this caused a Windows Firewall prompt to allow RAS server advertisements
#   Commented out "ras show user" <- This command enumerates all User accounts from the Active Directory and their Dial-in Settings, which can take a very long time in a big enterprise environment.
# Version 1.2
#   Corrected the section that collects RAS Tracing logs.
# Date: 2009, 2013, 2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about RAS.
# Called from: Main Networking Diag, etc
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable RasTracingStrings
Write-DiagProgress -Activity $RasTracingStrings.ID_RasTracingLogs -Status $RasTracingStrings.ID_RasTracingLogsDesc

$sectionDescription = "RAS Component"

function RunNetSH ([string]$NetSHCommandToExecute="")
{
	Write-DiagProgress -Activity $RasTracingStrings.ID_RasNetsh -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n"		| Out-File -FilePath $OutputFile -append
	"`n"		| Out-File -FilePath $OutputFile -append
	"`n"		| Out-File -FilePath $OutputFile -append
}


#----------Log Files
$RasTracing = "$Env:windir\tracing"
if (Test-Path -Path $RasTracing)
{
	if (-not (Test-Path($PWD.Path + "\RasTracingDir"))) {[void](New-Item $Pwd.Path -Name RasTracingDir -ItemType directory)}
	$RasTracingPath =  $Pwd.Path + "\RasTracingDir"
	Copy-Item  -Path "$Env:windir\tracing\*.*" -Destination $RasTracingPath
	$RasTracingFiles = $RasTracingPath + "\*.*"
	$RasTracingLogs = $ComputerName + "_RasTracingLogs.zip" 
	$zipComp = CompressCollectFiles -NumberofDays 10 -filesToCollect $RasTracingFiles -DestinationFileName $RasTracingLogs -renameOutput $false -fileDescription "RAS Tracing Logs" -sectionDescription $sectionDescription
	if ($zipComp) { Write-Verbose "_... zipped $RasTracingFiles"
		Remove-Item  -Path $RasTracingFiles -Recurse
		Remove-Item $Pwd.Path`\RasTracingDir }
}


#----------Registry
$OutputFile= $Computername + "_RAS_reg_.TXT"
$CurrentVersionKeys =   "HKLM\System\CurrentControlSet\services\RasMan"

RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "RAS registry output" -SectionDescription $sectionDescription



#----------Netsh
$OutputFile = $ComputerName + "_RAS_netsh_ras-output.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"RAS Netsh Output"										| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. netsh ras aaaa show accounting"					| Out-File -FilePath $OutputFile -append
"   2. netsh ras aaaa show acctserver"					| Out-File -FilePath $OutputFile -append
"   3. netsh ras aaaa show authentication"				| Out-File -FilePath $OutputFile -append
"   4. netsh ras aaaa show authserver"					| Out-File -FilePath $OutputFile -append
"   5. netsh ras aaaa show ipsecpolicy"					| Out-File -FilePath $OutputFile -append
"   6. netsh ras demanddial show interface"				| Out-File -FilePath $OutputFile -append
"   7. netsh ras demanddial show"						| Out-File -FilePath $OutputFile -append
"   8. netsh ras diagnostics show tracefacilities"		| Out-File -FilePath $OutputFile -append
"   9. netsh ras ip show config"						| Out-File -FilePath $OutputFile -append
"  10. netsh ras ip show preferredadapter"				| Out-File -FilePath $OutputFile -append
"  11. netsh ras ipv6 show config"						| Out-File -FilePath $OutputFile -append
"  12. netsh ras show authmode"							| Out-File -FilePath $OutputFile -append
"  13. netsh ras show authtype"							| Out-File -FilePath $OutputFile -append
"  14. netsh ras show client"							| Out-File -FilePath $OutputFile -append
"  15. netsh ras show conf"								| Out-File -FilePath $OutputFile -append
"  16. netsh ras show ikev2connection"					| Out-File -FilePath $OutputFile -append
"  17. netsh ras show ikev2saexpiry"					| Out-File -FilePath $OutputFile -append
"  18. netsh ras show link"								| Out-File -FilePath $OutputFile -append
"  19. netsh ras show multilink"						| Out-File -FilePath $OutputFile -append
"  20. netsh ras show portstatus"						| Out-File -FilePath $OutputFile -append
"  21. netsh ras show registeredserver"					| Out-File -FilePath $OutputFile -append
"  22. netsh ras show sstp-ssl-cert"					| Out-File -FilePath $OutputFile -append
"  23. netsh ras show status"							| Out-File -FilePath $OutputFile -append
"  24. netsh ras show type"								| Out-File -FilePath $OutputFile -append
"  25. netsh ras show wanports"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"											| Out-File -FilePath $OutputFile -append


"__ value of Switch skipHang: $Global:skipHang  - 'True' will suppress output for: NetSh ras show client `n`n"	| Out-File -FilePath $OutputFile -append

RunNetSH -NetSHCommandToExecute "ras aaaa show accounting"
RunNetSH -NetSHCommandToExecute "ras aaaa show acctserver"
RunNetSH -NetSHCommandToExecute "ras aaaa show authentication"
RunNetSH -NetSHCommandToExecute "ras aaaa show authserver"
RunNetSH -NetSHCommandToExecute "ras aaaa show ipsecpolicy"
RunNetSH -NetSHCommandToExecute "ras demanddial show interface"
RunNetSH -NetSHCommandToExecute "ras demanddial show"
RunNetSH -NetSHCommandToExecute "ras diagnostics show tracefacilities"
RunNetSH -NetSHCommandToExecute "ras ip show config"
RunNetSH -NetSHCommandToExecute "ras ip show preferredadapter"
RunNetSH -NetSHCommandToExecute "ras ipv6 show config"
# RunNetSH -NetSHCommandToExecute "ras show activeservers"              <- On Win7, this caused a Windows Firewall prompt to allow RAS server advertisements
RunNetSH -NetSHCommandToExecute "ras show authmode"
RunNetSH -NetSHCommandToExecute "ras show authtype"
if ($Global:skipHang -ne $true) {
	RunNetSH -NetSHCommandToExecute "ras show client"
	}
RunNetSH -NetSHCommandToExecute "ras show conf"
RunNetSH -NetSHCommandToExecute "ras show ikev2connection"
RunNetSH -NetSHCommandToExecute "ras show ikev2saexpiry"
RunNetSH -NetSHCommandToExecute "ras show link"
RunNetSH -NetSHCommandToExecute "ras show multilink"
RunNetSH -NetSHCommandToExecute "ras show portstatus"
RunNetSH -NetSHCommandToExecute "ras show registeredserver"
RunNetSH -NetSHCommandToExecute "ras show sstp-ssl-cert"
RunNetSH -NetSHCommandToExecute "ras show status"
RunNetSH -NetSHCommandToExecute "ras show type"
# RunNetSH -NetSHCommandToExecute "ras show user"                       <- This command enumerates  all User accounts from the Active Directory and their Dial-in Settings, which can take a very long time in a big enterprise environment.
RunNetSH -NetSHCommandToExecute "ras show wanports"

CollectFiles -sectionDescription $sectionDescription -fileDescription "RAS netsh output" -filesToCollect $OutputFile
