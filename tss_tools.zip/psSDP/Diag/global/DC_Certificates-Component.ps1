﻿#************************************************
# DC_Certificates-Component.ps1
# Version 1.1: Added the -silent switch. 11/2012
# Version 1.2: Added table of contents to output
# Version 1.3.08.22.14: The overview heading was missing from output file _Certificates-userstore.TXT. Corrected by moving $OutputFile definition to line 58. TFS264120
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information using CertUtil.exe.
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

	
$sectionDescription = "Certificates Information"

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber
	
Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSCertificates -Status $ScriptVariable.ID_CTSCertificatesDescription

Write-DiagProgress -Activity $ScriptVariable.ID_CTSCertificatesMachineStore -Status $ScriptVariable.ID_CTSCertificatesMachineStoreDescription
"[info]: Collecting information about certificates in the machine store."  | WriteTo-StdOut
$OutputFile = $ComputerName + "_Certificates-machinestore.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"Certificate Output with CertUtil (Machine Store)"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. certutil -v -silent -store my"						| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"certutil -silent -store my"							| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
#----------CertUtil -silent -store > Certificates_machinestore.txt
$CommandToExecute = "cmd.exe /c certutil -v -silent -store my >> $OutputFile"
RunCmD -commandToRun $CommandToExecute -CollectFiles $false
CollectFiles -filesToCollect $OutputFile -fileDescription "Certificate Output with CertUtil (Machine Store)" -SectionDescription $sectionDescription



Write-DiagProgress -Activity $ScriptVariable.ID_CTSCertificatesUserStore -Status $ScriptVariable.ID_CTSCertificatesUserStoreDescription
$OutputFile = $ComputerName + "_Certificates-userstore.TXT"
"[info]: Collecting information about certificates in the user store."  | WriteTo-StdOut
"===================================================="	| Out-File -FilePath $OutputFile -append
"Certificate Output with CertUtil (User Store)"			| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. certutil -silent -user -store my"				| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"certutil -silent -user -store my"						| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
#----------CertUtil -silent -user -store my > Certificates_userstore.txt

$CommandToExecute = "cmd.exe /c certutil -silent -user -store my >> $OutputFile"
RunCmD -commandToRun $CommandToExecute -CollectFiles $false
CollectFiles -filesToCollect $OutputFile -fileDescription "Certificate Output with CertUtil (User Store)" -SectionDescription $sectionDescription




#----------Registry
$OutputFile= $Computername + "_Certificates_reg_.TXT"
$CurrentVersionKeys =	"HKLM\SYSTEM\CurrentControlSet\services\crypt32",
						"HKLM\SYSTEM\CurrentControlSet\services\CryptSvc",
						"HKLM\SYSTEM\CurrentControlSet\services\CertPropSvc",
						"HKLM\SYSTEM\CurrentControlSet\services\SCardSvr",
						"HKLM\SYSTEM\CurrentControlSet\services\SCPolicySvc"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "Certificates Registry Keys" -SectionDescription $sectionDescription




#W2008+
if ($bn -gt 6000)
{
	#----------Certificates EventLogs (CAPI2)
	$sectionDescription = "Certificate EventLogs"
	$EventLogNames = "Microsoft-Windows-CAPI2/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}

