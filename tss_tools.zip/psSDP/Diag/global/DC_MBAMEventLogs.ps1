#************************************************
# DC_MBAMEventLogs.ps1
# Version 2.0.3
# Date: 8-26-2013
# Author: bley chen
# Description: This script calls TS_GetEvents.ps1 to export MBAM, BitLocker Event logs
#
# jasonf 
# Updated for Windows 8, 8.1 8-26-2013
# Updated for additional logs 8-26-2013:
#
# Microsoft-Windows-BitLocker-DrivePreparationTool/Admin
# Microsoft-Windows-BitLocker-DrivePreparationTool/Operational
# Microsoft-Windows-BitLocker-Driver-Performance/Operational
# Microsoft-Windows-BitLocker/BitLocker Management
# Microsoft-Windows-MBAM/Admin
# Microsoft-Windows-MBAM/Diagnostic
# Microsoft-Windows-MBAM/Operational
#
#Updated for additional logs 4-12-2014
#Microsoft-IIS-Configuration/Administrative
#Microsoft-IIS-Configuration/Analytic
#Microsoft-IIS-Configuration/Debug
#Microsoft-IIS-Configuration/Operational

#Updated for additional logs 5-22-2014
#MBAM-Web/*
#************************************************

if ((($OSVersion.Major -eq 6) -and ($OSVersion.Minor -ge 1)) -or ($OSVersion.major -eq 10))
{
	$EventLogNames = wevtutil.exe el | Select-String "(Microsoft-Windows-MBAM/*)|(bitlocker(?!\Stracing)|(IIS-Configuration/*)|(MBAM-Web/*))"
	if ($EventLogNames -ne $null)
	{
		Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames
	}
}

