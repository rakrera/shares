﻿#************************************************
# DC_HyperVNetworking.ps1
# Version 1.0.04.22.14: Created script.
# Version 1.1.04.26.14: Corrected formatting issues with PowerShell output using format-table
# Version 1.2.05.23.14: Added Get-SCIPAddress; Added Hyper-V registry output (and placed at the top of the script)
# Version 1.3.07.31.14: Moved the "Hyper-V Network Virtualization NAT Configuration" section into its own code block for WS2012R2+. 
# Date: 2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: PS cmdlets
# Called from: Networking Diags
#*******************************************************


Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}	
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}



$sectionDescription = "Hyper-V Networking Settings"

#----------Registry
$outputFile = $Computername + "_HyperVNetworking_reg_.TXT"
#grouped registry values together:
#  RegKeys: vmms;
#  RegKeys: vmsmp, smsp, vmsvsf, vmsvsp
#  RegKeys: vmbus, vmbushid, vmbusr
#  RegKeys: vmbusr, vmicguestinterface, vmicheartbeat, vmickvpexchange, vmicrdv, vmicshutdown, vmictimesync, vmicvss

$CurrentVersionKeys = 	"HKLM\SYSTEM\CurrentControlSet\services\vmms",
						"HKLM\SYSTEM\CurrentControlSet\services\vmsmp",
						"HKLM\SYSTEM\CurrentControlSet\services\VMSP",
						"HKLM\SYSTEM\CurrentControlSet\services\VMSVSF",
						"HKLM\SYSTEM\CurrentControlSet\services\VMSVSP",
						"HKLM\SYSTEM\CurrentControlSet\services\vmbus",
						"HKLM\SYSTEM\CurrentControlSet\services\VMBusHID",
						"HKLM\SYSTEM\CurrentControlSet\services\vmbusr",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicguestinterface",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicheartbeat",
						"HKLM\SYSTEM\CurrentControlSet\services\vmickvpexchange",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicrdv",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicshutdown",
						"HKLM\SYSTEM\CurrentControlSet\services\vmictimesync",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicvss"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $outputFile -fileDescription "Hyper-V Registry Keys" -SectionDescription $sectionDescription



# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile = $Computername + "_HyperVNetworking_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"Hyper-V Networking Settings Powershell Cmdlets"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Server Configuration"							| Out-File -FilePath $OutputFile -append
"  1. Get-VMHost"										| Out-File -FilePath $OutputFile -append
"  2. Get-VMHostNumaNode"								| Out-File -FilePath $OutputFile -append
"  3. Get-VMHostNumaNodeStatus"							| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Switch Configuration"							| Out-File -FilePath $OutputFile -append
"  1. Get-VMSwitch *"									| Out-File -FilePath $OutputFile -append
"  2. Get-VMSwitch * | fl"								| Out-File -FilePath $OutputFile -append
#_#"  3. Get-VMSwitchTeam -SwitchName ""vSwitch"" | fl -Property * " | Out-File -FilePath $OutputFile -append
"  3. Get-VMSwitchTeam -EA SilentlyContinue | fl -Property *" | Out-File -FilePath $OutputFile -append
#_#"  4. Get-VMSwitch -Name ""vSwitch"" | Get-VMSwitchExtension | fl -Property * " | Out-File -FilePath $OutputFile -append
"  4. Get-VMSwitch | Get-VMSwitchExtension | fl -Property *" | Out-File -FilePath $OutputFile -append
"  5. Get-VMSystemSwitchExtension | fl -Property * "	| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Adapter Configuration"					| Out-File -FilePath $OutputFile -append
"  1. Get-VMNetworkAdapter -ManagementOS"				| Out-File -FilePath $OutputFile -append
"  2. Get-VMNetworkAdapter -All"						| Out-File -FilePath $OutputFile -append
"  3. Get-VMNetworkAdapter *"							| Out-File -FilePath $OutputFile -append
"  4. Get-VMNetworkAdapter * | fl"						| Out-File -FilePath $OutputFile -append
"  5. Get-VMNetworkAdapter -ManagementOS | fl -Property *"		| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization Configuration"			| Out-File -FilePath $OutputFile -append
"  1. Get-NetVirtualizationCustomerRoute"				| Out-File -FilePath $OutputFile -append
"  2. Get-NetVirtualizationProviderAddress"				| Out-File -FilePath $OutputFile -append
"  3. Get-NetVirtualizationProviderRoute"				| Out-File -FilePath $OutputFile -append
"  4. Get-NetVirtualizationLookupRecord"				| Out-File -FilePath $OutputFile -append
"  4. Get-NetVirtualizationGlobal"						| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization SCVMM Configuration"	| Out-File -FilePath $OutputFile -append
"  1. Get-SCIPAddress"									| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization NAT Configuration [HNV Gateway]" | Out-File -FilePath $OutputFile -append
"  1. Get-NetNat"										| Out-File -FilePath $OutputFile -append
"  2. Get-NetNatGlobal"									| Out-File -FilePath $OutputFile -append
"  3. Get-NetNatSession"								| Out-File -FilePath $OutputFile -append
"  4. Get-NetNatStaticMapping"							| Out-File -FilePath $OutputFile -append
"  5. Get-NetNatExternalAddress"						| Out-File -FilePath $OutputFile -append	
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append


$vmmsCheck = Test-path "HKLM:\SYSTEM\CurrentControlSet\Services\vmms"
if ($vmmsCheck)
{
	if ((Get-Service "vmms").Status -eq 'Running')
	{
		if ($bn -gt 9000) 
		{
			"[info] Hyper-V Server Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Server Configuration"							| Out-File -FilePath $OutputFile -append	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-VMHost
			runPS "Get-VMHost"		-ft # W8/WS2012, W8.1/WS2012R2	# ft	
			$vmhost = get-vmhost
			runPS "Get-VMHostNumaNode"		-ft # W8/WS2012, W8.1/WS2012R2	# ft
			if ($vmhost.NumaSpanningEnabled -eq $false)
			{
				"NUMA Spanning has been disabled within Hyper-V Settings, running the `"Get-VMHostNumaNodeStatus`" ps cmdlet."		| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append				
				runPS "Get-VMHostNumaNodeStatus"			# W8/WS2012, W8.1/WS2012R2	# ft	
			}
			else
			{
				"------------------------"	| Out-File -FilePath $OutputFile -append
				"Get-VMHostNumaNodeStatus"	| Out-File -FilePath $OutputFile -append
				"------------------------"	| Out-File -FilePath $OutputFile -append
				"NUMA Spanning is NOT enabled. Not running the `"Get-VMHostNumaNodeStatus`" ps cmdlet."	| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append
			}

			
			"[info] Hyper-V Switch Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Switch Configuration"							| Out-File -FilePath $OutputFile -append	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-VMSwitch
			runPS "Get-VMSwitch *"	-ft 							# W8/WS2012, W8.1/WS2012R2	# ft	
			runPS "Get-VMSwitch * | fl"	-ft 						# W8/WS2012, W8.1/WS2012R2	# ft
			#_#runPS "Get-VMSwitchTeam -SwitchName ""vSwitch"" | fl -Property *" #-ft # W8/WS2012, W8.1/WS2012R2
			runPS "Get-VMSwitchTeam -EA SilentlyContinue | fl -Property *"
			#_#runPS "Get-VMSwitch -Name ""vSwitch"" | Get-VMSwitchExtension | fl -Property *"	#-ft # W8/WS2012, W8.1/WS2012R2
			runPS "Get-VMSwitch | Get-VMSwitchExtension | fl -Property *"
			runPS "Get-VMSystemSwitchExtension | fl -Property *" #-ft # W8/WS2012, W8.1/WS2012R2


			"[info] Hyper-V Network Adapter Configuration section."  | WriteTo-StdOut
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Network Adapter Configuration"					| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-VMNetworkAdapter
			runPS "Get-VMNetworkAdapter -ManagementOS"		-ft # W8/WS2012, W8.1/WS2012R2	# ft
			runPS "Get-VMNetworkAdapter -All"				-ft # W8/WS2012, W8.1/WS2012R2	# ft				
			runPS "Get-VMNetworkAdapter *"					-ft # W8/WS2012, W8.1/WS2012R2	# ft	
			runPS "Get-VMNetworkAdapter * | fl"					# W8/WS2012, W8.1/WS2012R2	# fl
			runPS "Get-VMNetworkAdapter -ManagementOS | fl -Property *"	# W8/WS2012, W8.1/WS2012R2	# fl	


			"[info] Hyper-V Network Virtualization Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Network Virtualization Configuration"			| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append		
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-NetVirtualization
			runPS "Get-NetVirtualizationCustomerRoute"			# W8/WS2012, W8.1/WS2012R2	# fl
			runPS "Get-NetVirtualizationProviderAddress"		# W8/WS2012, W8.1/WS2012R2	# fl	
			runPS "Get-NetVirtualizationProviderRoute"			# W8/WS2012, W8.1/WS2012R2	# unknown
			runPS "Get-NetVirtualizationLookupRecord"			# W8/WS2012, W8.1/WS2012R2	# fl
			runPS "Get-NetVirtualizationGlobal"					# W8/WS2012, W8.1/WS2012R2	# fl		#Added 4/26/14


			"[info] Hyper-V Network Virtualization Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Network Virtualization SCVMM Configuration"	| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append		
			"`n"	| Out-File -FilePath $OutputFile -append

			If (Test-path “HKLM:\SYSTEM\CurrentControlSet\Services\SCVMMService”)
			{
				if ($bn -ge 9600) 
				{
					runPS "Get-SCIPAddress"						# W8.1/WS2012R2	# fl
				}
				else
				{
					"This server is not running WS2012 R2. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
				}
			}
			else
			{
				"SCVMM is not installed."					| Out-File -FilePath $OutputFile -append
				"Not running the Get-SCIPAddress pscmdlet."	| Out-File -FilePath $OutputFile -append			
			}			
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
		}
		else
		{
			"This server is not running WS2012 or WS2012 R2. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The `"Hyper-V Virtual Machine Management`" service is not running. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Hyper-V Virtual Machine Management`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}


"[info] Hyper-V Network Virtualization Configuration section."  | WriteTo-StdOut	
"===================================================="	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization NAT Configuration"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append	
"`n"	| Out-File -FilePath $OutputFile -append
#_#if ($bn -ge 9600)
		#Get role, OSVer, hotfix data. #_#
		$cs =  gwmi -Namespace "root\cimv2" -class win32_computersystem -ComputerName $ComputerName #_#
		$DomainRole = $cs.domainrole #_#
if (($bn -ge 9600) -and ($cs.DomainRole -ge 2)) #_# not on Win8+,Win10 client
{
	# Hyper-V: Get-NetVirtualization
	runPS "Get-NetNat"						# W8.1/WS2012R2	# unknown		# Added 4/26/14
	runPS "Get-NetNatGlobal"				# W8.1/WS2012R2	# unknown		# Added 4/26/14
	"---------------------------"			| Out-File -FilePath $OutputFile -append
	"Get-NetNatSession"						| Out-File -FilePath $OutputFile -append
	"---------------------------"			| Out-File -FilePath $OutputFile -append
	"Not running Get-NetNatSession currently because of exception."			| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	#runPS "Get-NetNatSession"				# W8.1/WS2012R2	# unknown		# Added 4/26/14 -> commented out because of exception... Need a check in place.
	runPS "Get-NetNatStaticMapping"			# W8.1/WS2012R2	# unknown		# Added 4/26/14
	runPS "Get-NetNatExternalAddress"		# W8.1/WS2012R2	# unknown		# Added 4/26/14
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}
else
{
	"The Get-NetNat* powershell cmdlets only run on Server WS2012 R2+. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $outputFile -fileDescription "Hyper-V Networking Settings" -SectionDescription $sectionDescription
