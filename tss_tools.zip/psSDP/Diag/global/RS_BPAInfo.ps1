﻿#************************************************
# RS_BPAinfo.ps1
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

. ./utils_cts.ps1
SkipSecondExecution

if($debug -eq $true){[void]$shell.popup("Run RS_BPAInfo.ps1")}

$BPAXMLFile = [System.IO.Path]::GetFullPath($PWD.Path + ("\..\BPAResults.XML"))

if($debug -eq $true){[void]$shell.popup("BPAXMLFile: " + $BPAXMLFile)}

if (Test-Path $BPAXMLFile) {

	[xml] $XMLResults = Get-Content -Path $BPAXMLFile
	$BPAModels = $XMLResults.SelectNodes("(//BPAModel[Object[(Property[@Name=`'Severity`'] = `'Warning`') or (Property[@Name=`'Severity`'] = `'Error`')]])")
	$X = 0
	ForEach ($BPAModel in $BPAModels) 
	{ 
		forEach ($Object in $BPAModel.SelectNodes("(Object[(Property[@Name=`'Severity`'] = `'Warning`') or (Property[@Name=`'Severity`'] = `'Error`')])")){
			$X += 1
			$BPAMSG_Summary = new-object PSObject
			
			add-member -inputobject $BPAMSG_Summary -membertype noteproperty -name "Category" -value $Object.SelectSingleNode("Property[@Name='Category']").InnerText
			add-member -inputobject $BPAMSG_Summary -membertype noteproperty -name "Source" -value ($BPAModel.ReportTitle)
			add-member -inputobject $BPAMSG_Summary -membertype noteproperty -name "Resolution" -value $Object.SelectSingleNode("Property[@Name='Resolution']").InnerText
			add-member -inputobject $BPAMSG_Summary -membertype noteproperty -name "Additional Information" -value ("<a target=`"_blank`" href = `"" + $Object.SelectSingleNode("Property[@Name='Help']").InnerText + "`">" + $Object.SelectSingleNode("Property[@Name='Help']").InnerText + "</a>")
			
			$BPAMSG_Summary | ConvertTo-Xml2 | update-diagreport -ID ($X.ToString() + "_BPA") -name $Object.SelectSingleNode("Property[@Name='Problem']").InnerText -verbosity $Object.SelectSingleNode("Property[@Name='Severity']").InnerText
		}

		$MoreInfo_Summary = new-object PSObject
		$MoreInfoMsg = "Please open the <a href= `"`#" + $BPAModel.OutputFileName + "`">" + ($BPAModel.ReportTitle) + "</a> report for more information. You can calso go to the internal web site <a target=`"_blank`" href=`"http://winbpa`">http://winbpa</a> to submit a BPA rule suggestion."
		add-member -inputobject $MoreInfo_Summary -membertype noteproperty -name "Message" -value $MoreInfoMsg
		$MoreInfo_Summary | ConvertTo-Xml2 | update-diagreport -ID ($X.ToString() + "ZZ_BPA") -name "More Information" -verbosity "Informational"
	}
	
	Remove-Item $BPAXMLFile
}

if($debug -eq $true){[void]$shell.popup("RS_BPAInfo.ps1 finished")}
