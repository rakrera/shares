# Name: tss_update-script.ps1

<# 
.SYNOPSIS
	Script to auto-update tss to latest version or download latest zip from GitHub.

.DESCRIPTION
	Script will search on "https://api.github.com/repos/CSS-Windows/WindowsDiag/releases" for latest tss version
	If local version does not match the remote Github version, it will download and replace tss with latest version
	Script gets the current version by running "tss version".

.PARAMETER tss_action
	Specify action from allowed values: "Download" or "Update" or "Version"
	Ex: -tss_action "Download"
	
.PARAMETER tss_file
	Specify filename from allowed values: "tss_tools.zip" or "tss_tools_ttt.zip" or "tss_tools_diff.zip"
	Ex: -tss_file "tss_tools.zip"
	
.PARAMETER tss_path
	Specify the local path where tss.cmd is located.
	Ex: -tss_path "C:\Tss_tools"
.PARAMETER Folderpath
	Specify the local path where tss.cmd is located.
.PARAMETER UpdMode
	Specify the mode: Full= complete package (tss_tools.zip), Quick= differential package only (tss_diff.zip): replace only tss.cmd and tss_extra_*.* tss_config.* tss_stop_*.* files
.PARAMETER LKGVer
	Last-Known-Good tss version
.PARAMETER tss_arch
	Specify the System Architecture.
	Allowed values:
		x64 - For 64-bit systems
		x86 - For 32-bit systems
	Ex: -tss_arch "x64"

.EXAMPLE
	.\tss_update-script.ps1 -tss_action "Update" -tss_path "C:\Tss_tools" -tss_file "tss_tools.zip"
	Example 1: Update tss in folder C:\Tss_tools
	
.LINK
	https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/TSS
	https://api.github.com/repos/CSS-Windows/WindowsDiag/releases
#>


param(
	[ValidateSet("download","update","version")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: download|update|version')]
	[string]$tss_action 	= "download"
	,
	[string] $tss_path 		= (Split-Path $MyInvocation.MyCommand.Path -Parent)
	,
	[string]$Folderpath 	= (Split-Path $MyInvocation.MyCommand.Path -Parent)
	,
	[ValidateSet("Full","Quick","Force")]
	[string]$UpdMode 		= "Full"
	,
	$LKGVer
	,
	[ValidateSet("tss_tools.zip","tss_tools_ttt.zip","tss_tools_diff.zip")]
	[string] $tss_file 		= "tss_tools.zip"
	,
	[ValidateSet("x64","x86")]
	[string] $tss_arch 		= "x64"
)

#region  ::::: [Variables] -----------------------------------------------------------#
$ScriptVersion		= "1.09"	#2020-08-18
$tss_release_url 	= "https://api.github.com/repos/CSS-Windows/WindowsDiag/releases"
$UpdLogfile 		= $Folderpath + "\_tss_Update-Failed.txt"
$ChkFailed			= $FALSE

$invocation 		= (Get-Variable MyInvocation).Value
$scriptName 		= $invocation.MyCommand.Name
$ScriptBeginTimeStamp = Get-Date
#endregion  ::::: [Variables] --------------------------------------------------------#
	
# Check if last "\" was provided in $tss_path, if it was not, add it
if (-not $tss_path.EndsWith("\")){
	$tss_path = $tss_path+"\"
}

#region  ::::: [Functions] -----------------------------------------------------------#
function get_cur_tss_version (){
	<#
	.SYNOPSIS
		Function returns current tss versions locally from "tss version" command.
	#>
	# Regex for version number
	[regex]$regex = '\d+\.\d+\.\d+.\d+'
	
	# Build tss command and run it
	$command = "$tss_path" + "tss.cmd"
	$version = &$command version | Write-Output

	# Match and return versions
	[string]$version -match $regex > $null
	write-verbose "[Info] current installed version: $version"
	return $Matches[0]
}
function get_LKG_tss_version (){
	<#
	.SYNOPSIS
		Function returns LKG tss versions locally from "tss-LKG version" command.
	#>
	# Regex for version number
	[regex]$regex = '\d+\.\d+\.\d+.\d+'
	
	# Build tss command and run it
	$command = "$tss_path" + "tss-LKG.cmd"
	$version = &$command version | Write-Output

	# Match and return versions
	[string]$version -match $regex > $null
	write-verbose "[Info] LKG version: $version"
	return $Matches[0]
}

function get_latest_tss_version() {
	<#
	.SYNOPSIS
		Function will get latest version number from github Release page
	.LINK
		https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/TSS
	#>

	# Get web content and convert from JSON
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	try { $web_content = Invoke-WebRequest -Uri $tss_release_url -UseBasicParsing | ConvertFrom-Json } catch { "`n*** Failure during TSS update. Exception Message:`n $($_.Exception.Message)" | Out-File $UpdLogfile -Append }
	if ($web_content.tag_name) {
		[version]$expected_latest_tss_version = $web_content.tag_name.replace("v","")
		write-verbose "GitHub Version of '$tss_release_url': --> $expected_latest_tss_version"
		return $expected_latest_tss_version
		}
	else { Write-Host -foreground Red "[ERROR] cannot securly access $tss_release_url. Please download https://aka.ms/getTSS"
			"`n $ScriptBeginTimeStamp [ERROR] cannot securly access $tss_release_url. Please download https://aka.ms/getTSS" | Out-File $UpdLogfile -Append
			$ChkFailed=$TRUE
			return 2020.0.0.0}
}

function DownloadFileFromGitHubRelease {
	param($action = "download", $file, $installedTSSver)
	# Download latest CSS-Windows/WindowsDiag release from github
	$repo = "CSS-Windows/WindowsDiag"
	$releases = "https://api.github.com/repos/$repo/releases"
	#Determining latest release , Set TLS to 1.2
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	$tag = (Invoke-WebRequest $releases | ConvertFrom-Json)[0].tag_name
	$download = "https://github.com/$repo/releases/download/$tag/$file"
	Write-Verbose "download: https://github.com/$repo/releases/download/$tag/$file"
	$name = $file.Split(".")[0]
	$zip = "$name-$tag.zip"
	$TmpDir = "$name-$tag"
	Write-Verbose "Name: $name - Zip: $zip - Dir: $TmpDir - Tag/version: $tag"
	
	#_# faster Start-BitsTransfer $download -Destination $zip # is not allowed for GitHub
	Write-Host ".. Secure download of latest release: $download"
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	Invoke-WebRequest $download -OutFile $zip

	if ($action -match "download") {
		Write-Host -foreground Green "[Info] Downloaded version to folder: $tss_path$tss_file"
		}
	if ($action -match "update") {
		$orig_tss_path = (Split-Path $tss_path -Parent)
		if ($orig_tss_path -match "tss_tools") {Write-Host "[downlevel update]: $orig_tss_path matches tss_tools"
			$tss_path = $orig_tss_path
			}
		Write-Host "... saving a copy of installed tss.cmd to $($tss_path + "tss.cmd_v" + $installedTSSver)"
		Copy-Item ($tss_path + "tss.cmd") ($tss_path + "tss.cmd_v" + $installedTSSver) -Force -ErrorAction SilentlyContinue
		Write-Host "... saving a copy of current tss_config.cfg to $($tss_path + "tss_config.cfg_backup")"
		Copy-Item ($tss_path + "tss_config.cfg") ($tss_path + "tss_config.cfg_backup") -Force -ErrorAction SilentlyContinue
		Write-Host "[Expand-Archive] Extracting release files from $zip"
		Write-Verbose ".. Extracting release files from $zip to $ENV:temp\$TmpDir"
		Expand-Archive  -Path $zip -DestinationPath $ENV:temp\$TmpDir -Force
		Write-Host ".. Cleaning up .."
		Write-Verbose "Cleaning up target dir: Remove-Item $name -Recurse"
		Write-Verbose "Copying from temp dir: $ENV:temp\$TmpDir to target dir: $tss_path"
		Copy-Item $ENV:temp\$TmpDir\* -Destination $tss_path -Recurse -Force
		Write-Verbose "Removing temp file: $zip and folder $TmpDir"
		Remove-Item $zip -Force
		Write-Verbose "Remove-Item $ENV:temp\$TmpDir -Recurse"
		Remove-Item $ENV:temp\$TmpDir -Recurse -Force -ErrorAction SilentlyContinue
		if ($orig_tss_path -match "tss_tools") {
			Write-Host "[downlevel update]: copy tss.cmd and tss_update-script.ps1 to $tss_path"
			Copy-Item $ENV:temp\$TmpDir\tss.cmd -Destination $tss_path -Force
			Copy-Item $ENV:temp\$TmpDir\tss_update-script.ps1 -Destination $tss_path -Force
			Write-Host -foreground Green "[Info] New TSS version $expectedVersion is in folder: $tss_path"
			Remove-Item $ENV:temp\$TmpDir -Recurse -Force -ErrorAction SilentlyContinue
		}
	}
}

function TestGithubConn {
	if ($bn -gt 9600) { $checkConn = Test-NetConnection -ComputerName api.Github.com -CommonTCPPort HTTP -InformationLevel Quiet; return $checkConn}
	if ($bn -gt 7600) { $checkConn = Test-Connection -ComputerName api.Github.com -Quiet -Count 1; return $checkConn}
}
#endregion  ::::: [Functions] --------------------------------------------------------#

#region  ::::: [MAIN] ----------------------------------------------------------------#
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

# Check if Quick update is allowed: cur_tss_version -gt LKG_tss_version 
# if ($installedTSSver -gt $fileLKGVersion ) 
# if ($($installedTSSver.CompareTo($fileLKGVersion)) -eq 0) { # If versions match, display message
#			Write-Host -foreground Cyan "[Info] Latest Tss version $expectedVersion is installed.`n"}
## Check if installed current version is lower than latest GitHub Release version
#		elseif ($($installedTSSver.CompareTo($fileLKGVersion)) -lt 0) {

## :: Criteria to use Quick vs. Full update: current version is higher then LKGVer, updates in xray or psSDP, ...
# Choose download file based on $UpdMode (and current installed TSS build)
switch ($UpdMode) {
        "Full"  { $tss_file = "tss_tools.zip" }
        "Quick" { $tss_file = "tss_tools_diff.zip" }
		"Force" { $tss_file = "tss_tools.zip" }	#skip check version?
        default { $tss_file = "tss_tools.zip"}
        }
		
# Check for Internet connectivity // Test-NetConnection does not work for Win7
$checkConn = TestGithubConn
if ( $checkConn -eq "True") {
	# Determine which edition we need, ? based on existence of .\x64\TTTracer.exe
	$installedTSSver = New-Object System.Version(get_cur_tss_version)
	$fileLKGVersion  = New-Object System.Version(get_LKG_tss_version)
	$expectedVersion = New-Object System.Version(get_latest_tss_version)

	# Check if tss exists in $tss_path
	if (-not (Test-Path ($tss_path + "tss.cmd"))){
		Write-Host -foreground red "[Warning] tss.cmd could not be located in $tss_path"
		Write-Host
		DownloadFileFromGitHubRelease "update" $tss_file
	}


	if (Test-Path ($tss_path + "tss.cmd")){
		Write-Host "[Info] check current version $installedTSSver in $tss_path against latest released GitHub version $expectedVersion."
		if ($($installedTSSver.CompareTo($expectedVersion)) -eq 0) { # If versions match, display message
			Write-Host -foreground Cyan "[Info] Latest Tss version $expectedVersion is installed.`n"}
		# Check if installed current version is lower than latest GitHub Release version
		elseif ($($installedTSSver.CompareTo($expectedVersion)) -lt 0) {
			Write-Host -foreground red "[Warning] Actually installed Tss version $installedTSSver is outdated"
			Write-Host "[Info] Expected latest tss version on GitHub: $expectedVersion"
			Write-Host -foreground yellow "[Warning] ** Update will overwrite customized configuration, last tss_config.cfg is preserved in tss_config.cfg_backup. ** "
			switch($tss_action)
				{
				"download"		{ 	Write-Host "[download:] latest $tss_file"
									DownloadFileFromGitHubRelease "download" $tss_file $installedTSSver
								}
				"update"		{ 	Write-Host "[update:] to latest version $expectedVersion from GitHub " 
									 if (Test-Path ($tss_path + "x64\TTTracer.exe")) { Write-Host -foreground Yellow "[note:] This procedure will not refresh iDNA part"}
									DownloadFileFromGitHubRelease "update" $tss_file $installedTSSver
								}
				"version"		{ 	Write-Host -background darkRed "[version:] installed TSS version is outdated, please run 'TSS Update', trying AutoUpate" # or answer next question with 'Yes'"
									Write-Host -foreground Cyan "[Info] running AutoUpdate now... (to avoid updates, append TSS switch 'noUpdate')"
									DownloadFileFromGitHubRelease "update" $tss_file $installedTSSver
								}
				}
		}
		else {
			if ($ChkFailed) {Write-Host -foreground Gray "[Info] Version check failed! Expected version on Github: $expectedVersion. Please download https://aka.ms/getTSS `n"}
			Write-Verbose "Match: Current installed tss version:  $installedTSSver"
			Write-Verbose "Expected latest tss version on GitHub: $expectedVersion"
		}
	}
} else {Write-Host -foreground Red "[failed update] Missing secure internet connection to api.GitHub.com. Please download https://aka.ms/getTSS`n"}

$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)

Write-Host -foreground Black -background gray "[Info] Script $scriptName v$ScriptVersion execution finished. Duration: $Duration"
#Write-Host -foreground Black -background gray "[Info] you can safely IGNORE any Tss update error after this line:"
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# 
 ToDo: 
 - save any CX changed file like tss_config.cfg into a [backup_v...] subfolder with prev. version, --> easy restoration, if there is no schema change
	see "...saving a copy of installed tss.cmd  ..."
 - check for multiple versions on Github
 
- Implement a scheduled task for periodic update check
Example one-line command: schtasks.exe /Create /SC DAILY /MO 1 /TN "tss Updater" /TR "powershell \path\to\script\get-latest-tss.ps1 -tss_path 'path\to\where\tss\is' -tss_arch 'x64'" /ST 12:00 /F
	[/SC DAILY]: Run daily
	[/MO 1]: Every Day
	[/TN "tss Updater"]: Task Name
	[/TR "powershell \path\to\script\get-latest-tss.ps1 -tss_path 'path\to\where\tss\is' -tss_arch 'x64'"]: Command to run
	[/ST 12:00]: Run at 12 PM
	[/F]: Force update
#>
#endregion  ::::: [ToDo] -------------------------------------------------------------#