<# File tss_PrereqCheck.ps1 [-Folderpath -BoundPar] [-NrFilesToKeep] [-EtlBuf] [-ProcMNrFilesToKeep] [-DataDisk]
Note: needs update in ETLhash when TSS gets new Module
#>

<#
.SYNOPSIS
1. Get the currently running and forecasted number of TSS ETL sessions
2. Get the size of the system Disk or DataDisk and calculate expected diskspace needed
Script will return error code 1450 if expected number of total TSS ETL sessions would breach 55, or error code 112 if diskspace is low

.DESCRIPTION  
	1. Script will calculate the total number of TSS ETL sessions needed and bail out with error 1450 if the sum of currently running ETLs and needed ETLs is more than 55, and TSS will ask for confirmation.
	2. Script will bail out with error 112, if diskspace is low (less than estimated max ETL size), and TSS will ask for confirmation to continue.

.NOTES

.PARAMETER Folderpath
 	Specify the path to the output folder, i.e. "C:\MS_DATA" will store logfile in C:\MS_DATA\ComputerName__BCpercentCheck.txt"
	Default is current folder
.PARAMETER BoundPar
	the list of TSS modules or scenarios
.PARAMETER UseExitCode
	 This switch will cause the script to close after the error is logged if an error occurs.
	 It is used to pass the error number back to the task scheduler or CMD script.
.PARAMETER HostMode
	Log on screen
.PARAMETER ScriptMode
	Log to file
	
.EXAMPLE
.\tss_PrereqCheck.ps1 -BoundPar "SMBcli:NTFS" -Folderpath "C:\MS_DATA"
	Example 1: will check if 'TSS General SMBcli NTFS' will run without an ETL sessionor network trace being dropped and logfile will be in in C:\MS_DATA
#>

param(
	[string]$Folderpath = $(Split-Path $MyInvocation.MyCommand.Path -Parent),
	$BoundPar = "",												# example "SMBcli:NTFS"
	[string]$DataDisk = "C:",									# Drive-letter of resulting data disk
	[string]$FilenameList = "etl procmon ndiscap NMcap",		#
	[int32]$NrFilesToKeep = 10,									# number of ETL files to keep
	[int32]$ProcMNrFilesToKeep = 9,								# number of Procmon files to keep
	[int32]$EtlBuf = 1024,										# ETL buffer size, default=1024 MB =1 GB
	[switch]$UseExitCode = $true,								# This will cause the script to bail out after the error is logged if an error occurs.
	[switch]$HostMode  	= $false, 								# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false								# This tells the logging functions to show logging in log file
)


#region: customization section of script, logging configuration ----------------------#
  $ErrorActionPreference = "Continue" #"Stop"
	$VerMa="1"
	$VerMi="02"
	$LogFileScript = $Folderpath +"\"+ $ENV:ComputerName + "__PrereqCheck.txt"
	$ErrorThrown = $null
	$ScriptVersion=1.06	#2020-08-27
#endregion: customization section of script, logging configuration
$scriptName = $MyInvocation.MyCommand.Name
$ScriptBeginTimeStamp = Get-Date


#region: Helper Functions
function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
    if($Script:ScriptMode){
      if($NoNewLine) {
        $Script:Trace += "$line"
      }
      else {
        $Script:Trace += "$line`r`n"
      }
      Set-Content -Path $Script:LogFileScript -Value $Script:Trace
    }
    if($Script:HostMode){
      $Params = @{
        NoNewLine    = $NoNewLine -eq $true
        ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
      }
      Write-Host $line @Params
    }
  }

  function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
    if($WaitForResult){
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
    }
    else{
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
    }
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
  }

  function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
    if($Pass){
      WriteLine " - Pass" -ForegroundColor Cyan
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
      }
    }
    if($Success){
      WriteLine " - Success" -ForegroundColor Green
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
      }
    }
  }

  function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
    WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
  }

  function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
    WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
  }

  function WriteError([string]$message){
	# SYNOPSIS: logs errors
    WriteLine ""
    WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
  }

  function WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
    WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
    Write-Host "Press any key to continue ..."
    $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
    $HOST.UI.RawUI.Flushinputbuffer()
    Throw "Terminating Error"
  }
  
function ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		WriteInfo "Return Code $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		} #end UseExitCode
}
function ToggleRegToolsVal ($TmpVal) {
	# Temporary set DisableRegistryTools=0, if it has been set  to 1 per policy to enable REG.EXE outputs
	$DisableRegistryTools = (Get-ItemProperty -ErrorAction SilentlyContinue -Path Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System).DisableRegistryTools
	if ($DisableRegistryTools) { 
		WriteLine " Registry editing has been disabled by your administrator.`n Current value of Reg-Key DisableRegistryTools = $DisableRegistryTools `n"
		Set-ItemProperty -ErrorAction SilentlyContinue -Path Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name DisableRegistryTools -Value $TmpVal
	} else {WriteLine "OK, Registry editing is not disabled for REG.EXE.`n"}
}
#endregion: Helper Functions

#region ::::: CONSTANTS AND VARIABLES ------------------------------------------------#
$ExitCode = 0
$LogLevel = 0
$ETLhash = @{ # hashtable module/scenario | Nr-of-ETLs
# Modules
	'cliOn' = '9'	# cli
	'srvOn' = '7'	# srv
	'cli' = '9'	# cliOn
	'srv' = '7'	# srvOn
	'ADcore' = '1'
	'ADsam' = '1'
	'AfdTcp' = '3'
	'AppLocker' = '1'
	'AppV' = '1'
	'ATA' = '1'
	'BGP' = '1'
	'BITS' = '1'
	'Bluetooth' = '1'
	'CDROM' = '1'
	'CSVspace' = '1'
	'customETL' = '1'
	'DCLocator' = '1'
	'DCOM' = '1'
	'Dedup' = '2'
	'DfsR' = '1'
	'EFS' = '1'
	'FSRM' = '1'
	'FWmgr' = '1'
	'GPsvc' = '1'
	'GroupPolicy' = '1'
	'HttpSys' = '1'
	'ICS' = '1'
	'IPsec' = '1'
	'iSCSI' = '1'
	'LBFO' = '1'
	'LDAPcli' = '1'
	'LDAPsrv' = '1'
	'MPIO' = '1'
	'MsDSM' = '1'
	'MUX' = '1'
	'NCHA' = '1'
	'NDIS' = '1'
	'NdisWan' = '1'
	'NFC' = '1'
	'NetworkUX' = '1'
	'NLA' = '2'
	'NTFS' = '1'
	'Outlook' = '1'
	'OLE' = '1'
	#'Perfmon' = '1'
	#'PerfmonLong' = '1'
	'PNP' = '1'
	'PortProxy' = '1'
	'PowerShell' = '1'
	#'ProcMon' = '1'
	'Profile' = '2'
	'RadioManager' = '1'
	'RAmgmt' = '1'
	'RASdiag' = '14'		# 'Netsh Ras diagnostics set trace enable' %SystemRoot%\tracing 
	'RasMan' = '1'
#	'ReproStandard' = '0'
	'Rpc' = '1'
	'SCM' = '1'
	'SCCM' = '1'
	'SmartCard' = '2'
	'SNMP' = '1'
	'Storage' = '1'
	'StorageReplica' = '1'
	'StorageSpace' = '1'
	'StorPort' = '1'
	'TaskSch' = '1'
	'TLS' = '2'
	#'Trace' = '1'
	'UEV' = '1'
	'USB' = '1'
	'VDS' = '1'
#	'Video' = '0'
	'VirtualFC' = '1'
	'VML' = '1'
	'VmSwitch' = '1'
	'VSS' = '2'
	'WCM' = '1'
	'WebIO' = '1'
	'WFPdiag' = '1'		# 'netsh wfp capture start file=wfpDiag.cab'
	'WinLogon' = '1'
	'WinNAT' = '1'
	'WinRM' = '2'
	'WmbClass' = '1'
	'WMI' = '1'
	'WSB' = '1'
	'WWAN' = '1'
# Scenarios
	'802Dot1x' = '0' #+3+1+14+2+1+1		# + AfdTcp NDIS RASdiag TLS WCM Procmon 
	'Auth' = '12' #5+7+1+1+1+1+2		# LSA Ntlm_CredSSP Kerberos Kdc + NGC BIO Sam CryptNcryptDpapi WebAuth Smartcard CredprovAuthui & cli DCLocator WFPdiag WinLogon Procmon TLS
	'Branchcache' = '1' #+1				# + BITS
	'Container' = '2' #+3+1+1+1			# + AfdTcp WFP VmSwitch WinNAT
	'CSC' = '0'							#
	'DAcli' = '0' #+1+2					# + WFPdiag, TLS
	'DAsrv' = '3' #+3+1+14+1+1+2+1+1	# + AfdTcp NDIS RASdiag LDAPcli RAmgmt TLS WinNAT WFPdiag
	'DFScli' = '0' #+5+1				# + cli Procmon
	'DFSsrv' = '1' #+7					# + srv
	'DHCPcli' = '1' #+1					# + DNScli
	'DHCPsrv' = '1' #+1					# + DNScli
	'DNScli' = '1'						# 
	'DNSsrv' = '1'						# 
	'Firewall' = '1'					# 
	#'General' = '0'						# 
	'HypHost' = '5' #+1+1+0+0+1+0		# + LBFo NDIS SMBcli SMBsrv VmSwitch VirtualFC
	'HypVM' = '2' #+1					# HypVM,Diagnostic + NDIS
	'IIS' = '0' #+1+2					# + HttpSys TLS
	'IPAM' = '1'						# 
	'MBAM' = '1'						# 
	'MBN' = '2' #+3+1+1+14+1+1+1+1+1	# + AfdTcp DNScli Procmon RASdiag RasMan RadioManager VPN WFP WCM
	'Miracast' = '0'					#
	'MsCluster' = '3' #+3+1+1			# + AfdTcp LBFo StorPort
	'NCSI' = '0' #+1+1  				# + Procmon WFPdiag
	'NetIO' = '1' #+3+1					# + AfdTcp WFP
	'NFScli' = '0' #+5+1				# + cli Procmon
	'NFSsrv' = '1' #+7					# + srv
	'NLB' = '2' #+3						# NLB, Event Diagnostic + AfdTcp
	'NPS' = '1' #+3+14+1+2+1			# + AfdTcp RASdiag LDAPcli TLS WFP
	'Proxy' = '0' #+0+1+0+0+1+1			# + NCSI WebIO WinInet WinHTTP Winsock Procmon
	'RAS' = '1' #+3+1+14+1+1+2+1+1		# + AfdTcp NDIS RASdiag LDAPcli RAmgmt TLS WinNAT WFPdiag
	'RDMA' = '3' #+3+1+1				# + AfdTcp NDIS NetIO
	'RDScli' = '7'						# 
	'RDSsrv' = '15'						# 
	'SBSL' = '1'						# =UNChard
	'SdnNC' = '5' #+1+1+1+1+2+1			# + HttpSys LBFo MUX NCHA TLS VmSwitch
	'SMBcli' = '3'						# + cli
	'SMBsrv' = '2'						# + srv
	'SQLtrace' = '0' #+1				# + Perfmon
	'UNChard' = '1' #+5+2+1+1+1			# + cli Profile WinLogon DCLocator Procmon
	'VPN' = '1' #+3+1+14+1+1+1			# + AfdTcp NetIO RASdiag WFP WFPdiag Procmon
	'WebClient' = '0' #+1+0+2+1			# + WebIO Proxy TLS Procmon
	'WFP' = '1' #+3+1+1+1           	# + AfdTcp NetIO WfpDiag Procmon
	'Winsock' = '1' #+3+1+1				# + AfdTcp NetIO NDIS
	'WIP' = '7'	#+1+1+1					# = AgileVpnEtwTracing RRASEtwTracing WFP WFPdiag 3x WPR + AppLocker, Procmon 
	'WLAN' = '0' #+3+1+1+14+1+2+1+1		# + AfdTcp NDIS NetworkUX RASdiag RadioManager TLS WCM Procmon   
	'WNV' = '1' #+3+1+1+1				# + AfdTcp LBFo NCHA VmSwitch
	'Workfolders' = '3' #+1				# + Perfmon
# TOOLS with ETL/dmp WPR
	'Trace' = '1'
	'TraceChn' = '1'
	'TraceNM' = '1'
	'TraceNMchn' = '1'
	'Perfmon' = '1'
	'PerfmonLong' = '1'
	'PktMon' = '1'
	'ProcMon' = '1'						# 1 session with max 9 x ~300MB
	'WPR' = '1'							# 1 session with max 2GB
	'xPerf' = '2'						# 1 Kernel + UserTrace session with max 2GB
	#'ProcDump' = '0'					# default 3 * 512MB ?
}
#endregion ::::: CONSTANTS AND VARIABLES ------------------------------------------------#
<#
'RASdiag' = '14' : 'Netsh Ras diagnostics set trace enable' %SystemRoot%\tracing 
	AgileVpn-EtwTracing	"Microsoft-Windows-Ras-AgileVpn"
	IPSEC				{6537B295-83C9-4811-B7FE-E7DBF2F22CEC}
	Ikeext				{106B464D-8043-46B1-8CB8-E92A0CD7A560}	# also in wfpDiag
	RASMBMGR			{A98F61AF-55A4-4D99-8EDE-217642BD02B8}
	RASL2TP				{D58C126E-B309-11D1-969E-0000F875A5BC}
	RASSSTP				{FF5E7768-8EF5-48B1-9998-61FC841D124F}
	RASPPTP				{D58C126F-B309-11D1-969E-0000F875A5BC}
	RASGRE				{06D47FAA-D591-450D-9805-2FA47D380B41}
	RASCUSTOM			{114C0AC9-DF95-450F-B769-E9D85E783A64}
	RASMAN				{B9F181E1-E221-43C6-9EE4-7F561315472F}
	RASEAP				"Microsoft-Windows-EapHost"
	RRAS-EtwTracing		"Microsoft-Windows-RRAS"
	VPNIKE				{AEFAA562-EBC7-4CA1-B2DE-F88462C448EC}
	VpnPlugin			{39C9F48F-D244-45A8-842F-DC9FBC9B6E92}

'WFPdiag' = '16'		# 'netsh wfp capture start file=wfpDiag.cab'
	wfpDiag				{106B464A-8043-46B1-8CB8-E92A0CD7A560} {AD33FA19-F2D2-46D1-8F4C-E3C3087E45AD} {106B464D-8043-46B1-8CB8-E92A0CD7A560} {5A1600D2-68E5-4DE7-BCF4-1C2D215FE0FE}
					=	BFE Trace Provider						FWPKCLNT Trace Provider					IKEEXT Trace Provider					FWPUCLNT Trace Provider

'netsh trace show scenario WFP-IPsec'
	Name:               Microsoft-Windows-WFP
	Provider Guid:      {0C478C5B-0351-41B1-8C58-4A6737DA32E3}
	Provider Guid:      {60523747-6516-48B7-84B1-3264FA2CB359}
	Name:               Microsoft-Windows-NetworkSecurity
	Provider Guid:      {7B702970-90BC-4584-8B20-C0799086EE5A}
	Name:               Microsoft-Windows-Windows Firewall With Advanced Security
	Provider Guid:      {D1BC9AFF-2ABF-4D71-9146-ECB2A986EB85}
#>

#region: MAIN

try{
	WriteInfoHighlighted -message "Starting 'tss_PrereqCheck.ps1' on $(Get-Date)" -pass
	
	# OSversion and Get-Culture info
	$wmiOSVersion 	= gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	$OSver 			= $wmiOSVersion.Version
	[int]$bn 		= [int]$wmiOSVersion.BuildNumber
	$CultureName 	= (Get-Culture).EnglishName
	#$CulturProps 	= Get-Culture | Format-List -Property *
	WriteInfo ".. running on Win $OSver - Culture: $CultureName"

	# 
	ToggleRegToolsVal 0
	
	# 1. calculate the total number of TSS ETL sessions needed and bail out with error 1450 if the sum of currently running ETLs and needed ETLs is more than 55
	WriteInfo -message "..checking ETL list: '$BoundPar'"
	if ($BoundPar -ne $null) {
		$BoundPar = $BoundPar -split ":" # ","
		for ($i = 0; $i -lt $BoundPar.Count; $i++) {
			$BoundPar[$i] = $BoundPar[$i].Replace(' ', ' ')
		}
	}
	
	# calculate nr of running ETL sessions
	$LogManQ_ets = (logman query -ets | Where-Object { ("unning Activo cution riendo eführt ecução uzione") -match (-join $_[-7..-1])}) #_# last 6 chars for localized LogMan terms (english "Running") - Full list: "Running  Activo  En cours d’exécution  Corriendo  Wird ausgeführt  Em execução  In esecuzione"
	$ETLsRunningCount = $LogManQ_ets.count
	if ($ETLsRunningCount -eq "2") { #_# don't check for localized 'Running', deduct 3 for header and footer lines - on Japanese/Chinese OS
		Write-host "Localized OS: $LogManQ_ets"
		$LogManQ_ets = (logman query -ets)
		$ETLsRunningCount = ($($LogManQ_ets).count -3) 
	}
	# for non-localized OS
		$LogManList = $LogManQ_ets.Replace("Trace                         Running"," ")
		$LogManList = $LogManList -replace '\s+', ' '
	WriteLine "`n"
	WriteInfo "List of running Data Collector Sets:"
	WriteLine "$LogManList"
	WriteLine "`n"
	WriteInfo -message "Nr of already running ETL sessions           : $ETLsRunningCount"

	# calculate nr of needed ETL sessions based on TSS input parameters
	foreach ($item in $BoundPar) {
		foreach($key in $ETLhash.keys)
		{
			$message = '  +needed {1} for {0}' -f $key, $ETLhash[$key]
			if ($item -eq $key) { WriteLine $message
									$SumOfSessionsNeeded += [int]$ETLhash[$key]
									}
		}
	}
	WriteInfo -message "Calculated ETL nr based on given TSS command : $SumOfSessionsNeeded"
	WriteInfo -message "Sum of ETLs running ($ETLsRunningCount) + needed ($SumOfSessionsNeeded)       = $($ETLsRunningCount + $SumOfSessionsNeeded)"

	# 2. calculate approx needed diskspace
	WriteLine "`n"
	WriteInfo -message  "Calculate approx needed diskspace for given TSS parameters:"
	WriteInfo -message  "  Trace NrFilesToKeep     : $NrFilesToKeep"
	WriteInfo -message  "  EtlBuffer size          : $EtlBuf MB"
	WriteInfo -message  "  ProcMon pml to keep     : $ProcMNrFilesToKeep"
	WriteInfo -message  "  Data Folder Folderpath  : $Folderpath"
		$FileCriteriaList = ($FilenameList.Trim() -split " ") 
	WriteInfo -message  "  FileCriteriaList        : '$FileCriteriaList' `n "
	$calcETL = $($NrFilesToKeep * $SumOfSessionsNeeded * $EtlBuf ) / 1kB
	WriteInfo -message  "  ETL files size (in GB ) : $calcETL GB"
	if ( $BoundPar -match "ProcMon") { 
			$calcProcM = [math]::Round( $($ProcMNrFilesToKeep * 300) / 1kB )
			WriteInfo -message  "  $ProcMNrFilesToKeep Procmon *.pml files   : $calcProcM GB"
	}
	$TotalEstimate = $calcETL + $calcProcM + 0.4	# ~ 0.4GB for support logs, SDP
	WriteInfo -message  "  Total estimated space   : $TotalEstimate GB"
	$FreeSpace = [math]::Round((Get-CimInstance -Class CIM_LogicalDisk | Select-Object * | Where-Object DriveType -eq "3"  | Where-Object DeviceID -eq "$DataDisk").FreeSpace / 1GB)
	WriteInfo -message  "  Total free space on $DataDisk  : $FreeSpace GB"


	$message = "`n[Info] Diskspace (estimated), for a very long-time repro: Expected minimum required diskspace on `n        disk $DataDisk is $calcETL GB ETL's + $calcProcM GB ProcMon + 0.4 GB = $TotalEstimate GB total, excluding *.txt/iDNA/ProcDump `n        FreeSpace: $FreeSpace GB`n"
	WriteInfo -message $message
	# Write [INFO] on low diskspace < 5GB
	if (($FreeSpace - $TotalEstimate) -lt 5) {
		if ($ScriptMode) {Write-Host -ForegroundColor Yellow $message}
	}	
	# if expected DiskSpace > FreeSpace stop early with Code 112 ERROR_DISK_FULL
	if ($TotalEstimate -ge $FreeSpace) { 
				$message  = " [Warning] Resulting (long term) dataset might not fit on this disk. `n  Total free space on $DataDisk ($FreeSpace GB) is less than max estimated ($TotalEstimate GB) `n  Consider i.e Tss switch 'DataDisk:E' for storing data on a different disk with more Free_Diskspace E:"
				WriteError -message $message
				if ($ScriptMode) {
					Get-WmiObject Win32_LogicalDisk  -Filter DriveType=3 | Select-Object DeviceID, @{'Name'='Size (GB)'; 'Expression'={[math]::truncate($_.size / 1GB)}}, @{'Name'='Freespace (GB)'; 'Expression'={[math]::truncate($_.freespace / 1GB)}} | out-Host
					#$DiskSpaceTable = Get-WmiObject Win32_LogicalDisk  -Filter DriveType=3 | Select-Object DeviceID, @{'Name'='Size (GB)'; 'Expression'={[math]::truncate($_.size / 1GB)}}, @{'Name'='Freespace (GB)'; 'Expression'={[math]::truncate($_.freespace / 1GB)}} | Out-File $Script:LogFileScript -Encoding ascii -Append
					Write-Host -ForegroundColor Red $message
				}
				$ExitCode = 112
	}
	# if running $ETLsRunningCount + needed $SumOfSessionsNeeded < 55 , continue - else stop early  with Code 1450 ERROR_NO_SYSTEM_RESOURCES
	$DiffETL = ($($ETLsRunningCount + $SumOfSessionsNeeded) - 55)
	If ($DiffETL -gt 0) {
		$message =  " Based on $ETLsRunningCount currently running (non TSS sessions) and $SumOfSessionsNeeded needed TSS ETL sessions you need to take action for a successfull TSS dataset!`n [Action] Please stop at least $DiffETL of unneccessary running Data Collector Sets (max allowed total=55)`n `t1. 'LogMan query -ets' `n`t2. 'LogMan stop -ets -n <name-of-Data Collector Set>'`n or tune the TSS command to use less ETL sessions.`n"
		WriteError $message
		if ($ScriptMode) { Write-Host -ForegroundColor Red $message
							Write-Host "[$OSver] Currently these Data Collector Sets are running:`n $LogManList`n"}
		$ExitCode = 1450
	} else { $message = "[Info] all $SumOfSessionsNeeded Tss ETL sessions should start normally..."
			WriteResult $message -pass
			if (($ScriptMode) -and ($SumOfSessionsNeeded -gt 0)) {Write-Host -ForegroundColor Cyan $message}
			}
	if ($ExitCode) { ExitWithCode $ExitCode }
}
catch{
  WriteError -message "An Error occured"
  WriteError -message $error[0].Exception.Message
  $ErrorThrown = $true
}
finally{
  $ScriptEndTimeStamp = Get-Date
  $LogLevel = 0
  WriteInfoHighlighted -message "Script $scriptName v$VerMa.$VerMi execution finished. Duration interaction: $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)" -pass

  if($ErrorThrown) {Throw $error[0].Exception.Message}
}
#endregion: MAIN

<#

		Based on xx currently running (non TSS sessions) and yy needed TSS ETL sessions you need to take action for a successfull TSS dataset!
		[Action] Please stop at least zz of unneccessary running Data Collector Sets (max allowed total=55)
			1. 'LogMan query -ets' 
			2. 'LogMan stop -ets -n <name-of-Data Collector Set>'
		or tune the TSS command to use less ETL sessions.
#>