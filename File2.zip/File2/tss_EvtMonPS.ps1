<# Name: tss_EvtMonPS.ps1 [-EventIDs -EventlogName -CheckIntInSec -WaitTimeInSec -EventData -EvtDataPartial]
	
if you invoke from CMD:
 PowerShell -noprofile "&{Invoke-Command -ScriptBlock {$EventID=30800;$NrOfMilliSec=60000;$EventlogName="Microsoft-Windows-SmbClient/Operational"; Get-WinEvent -LogName $EventlogName -FilterXPath "*[System[EventID=$EventID and TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]]" -MaxEvents 5 -ErrorAction SilentlyContinue}}"
 PowerShell -noprofile "&{Invoke-Command -ScriptBlock {Get-WinEvent -LogName "Microsoft-Windows-SmbClient/Operational"  -FilterXPath "*[System[EventID=30800]]" -MaxEvents 3 -ErrorAction SilentlyContinue }}"

	#Eventlogs location on disk: "C:\Windows\System32\winevt\Logs\Microsoft-Windows-SmbClient%4Operational.evtx"
Example to delete Source
 Get-WmiObject win32_nteventlogfile -Filter "logfilename='Microsoft-Windows-SmbClient/Operational'" | foreach {$_.sources}
 Remove-Eventlog -Source "TSS"

For Testing:
 you can watch for 40961/40962 in "Microsoft-Windows-PowerShell/Operational", which is logged when starting a  new PoSh window
#>

<#
.SYNOPSIS
Purpose: Monitor Eventlogs for specific event and stop script; in combi with TSS: stop the script based on EventIDs in a non classic Eventlog
	The stop trigger condition is true if the EventID is found in specified Eventlog up to CheckIntInSec back in time, the control is given back to calling script.
	From CMD script you can invoke this PowerShell script by: Powershell -noprofile -file "tss_EvtMon.ps1" -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 0
	Multiple EventIDs are separated by '/', for example -EventID 40961/40962
	Multiple EventData strings are separated by '/', for example -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 
SYNTAX: .\tss_EvtMon.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 'find-my-string'


.DESCRIPTION
The script will stop, once the specific details EventID(s) and Eventdata string(s) are all met.
You need to run the script in Admin PowerShell window, if you want to monitor 'Security' Event Log
You can append the -verbose parameter to see more details.
When entering -EventData string, please enter the complete string as seen in Event 'XML View', for example 'C:\Windows\System32\calc.exe'
 as seen in 'XML View' <Data Name="NewProcessName">C:\Windows\System32\calc.exe</Data> 
In additin to any specific EventID, the script will also listen on EventID 999 in Application eventlog, and stop when it sees 999 sent by a remote system as a stop trigger.

.PARAMETER EventIDs
	The Event ID wot watch for, separate multiple IDs with '/', ex: 30800/30809
.PARAMETER CheckIntInSec
	Specify how often (time-interval in seconds) to search for given EventID(s)
.PARAMETER EventlogName
	Specify name of Eventlog, i.e. "Microsoft-Windows-PowerShell/Operational" or "Microsoft-Windows-SmbClient/Operational"
.PARAMETER WaitTimeInSec
	Force a wait time in seconds after an event is found,  this will instruct tss to stop x seconds later.
.PARAMETER EventData
	Specify a complete string that is seen in Eventlog XML view <Data>"your complete string"</Data>
.PARAMETER EvtDataPartial
	Specify a unique keyword that is part of the complete message, to allow search for partial event data message
	This does not require a full string between <Data> .. </Data>, partial match is ok
	
.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 0

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 4688/4689 -EventlogName "Security" -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe -verbose
 
This will monitor for multiple EventIDs  4688 and 4689, checking if either string 'C:\Windows\System32\calc.exe' or 'C:\Windows\System32\cmd.exe' exist in given EventID(s) 

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 40961/40962 -EventlogName "Microsoft-Windows-PowerShell/Operational" -EventData 0
 
 This will monitor for multiple EventIDs 40961 and 40962 in Microsoft-Windows-PowerShell/Operational, will be triggered as soon as a new PowerShell window opens
 
 .EXAMPLE

  for testing it is sufficient to specify an existing "Source", i.e.
  Write-EventLog -LogName "Application" -Source "Outlook" -EventID 59 -EntryType Information -Message "Test this EventID as stop trigger." -Category 1 -RawData 10,20 -ComputerName $Env:Computername
  Note, you can also use the script tss_EventCreate.ps1 to fire such event.

.LINK
waltere@microsoft.com;Sergey.Akinshin@microsoft.com
#>

Param(
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose the EventID, or multiple separated by slash / ')]
	[string[]]$EventIDs 		# separate multiple IDs with '/', ex: 30800/30809
	,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Choose name of EventLog-File' )]
	[string]$EventlogName 		# name of Eventlog, i.e. "Microsoft-Windows-PowerShell/Operational" #"Microsoft-Windows-SmbClient/Operational"
	,
	[Parameter(Mandatory=$False,Position=1,HelpMessage='Choose the amount of time to search back in seconds ')]
	[Int32]$CheckIntInSec = 2	# specify time-interval in seconds to search back, # how often in seconds should the evenlog file be scanned?
	,
	[Parameter(Mandatory=$False,Position=3,HelpMessage='Choose Stop WaitTime in Sec')]
	[Int32]$WaitTimeInSec = 0	# this specifis the forced wait time after an event is detected
	,
	[Parameter(Mandatory=$False,Position=4,HelpMessage='optional: complete string in any EventData, or multiple separated by slash / ')]
	[string[]]$EventData = '0'	#'3221226599' # = STATUS_FILE_NOT_AVAILABLE / '3221225996' = STATUS_CONNECTION_DISCONNECTED / '0' = STATUS_SUCCESS
	,
	[Parameter(Mandatory=$False,Position=5,HelpMessage='Search for keywords in event Message')]
	[Switch]$EvtDataPartial		# allow search for partial event data message
)

#region: customization section of script, logging configuration ----------------------#
$ScriptVer			= "1.08"	# Date: 2020-05-21


[Int32]$cntr		= 0			# counter
[Int32]$MaxEvents	= 1			# we are only interested in a single occurence of EventID in Eventlog
$Trigger			= $False	# initialize 
[Int32]$NrOfMilliSec = 1000 * ($CheckIntInSec +5)	#amount of time in MilliSec to search back
#endregion: customization section of script, logging configuration -------------------#

#region: MAIN section of script ------------------------------------------------------#
[string[]]$Event_ID_list=$EventIDs.split("/")
Write-verbose "--EventIDs: $Event_ID_list"
[array]$xpaths= @()
$EvtDataStrings=$EventData.split("/")
[string[]]$EvtDataStrings_Or=$EventData.replace("/","|")

Write-verbose "--EvtDataStrings: $EvtDataStrings"
Write-verbose "--EvtDataStrings_Or: $EvtDataStrings_Or"


foreach ($EventID in $Event_ID_list){
		if ($EvtDataPartial) { # This does not require a full string between <data> .. </data>, partial match is ok
				$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
"@
		$xpaths += $xpath
		Write-host "---- EventID: $EventID - Xpath: `n$xpath"
		} else {
			foreach ($EvtDataString in $EvtDataStrings)
			{
			# full match of 'EvtDataString'
						if ($EventData -ne '0') {
							$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
[EventData[Data='$EvtDataString']]
"@
						} else {
						$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
"@
						}
			
			$xpaths += $xpath
			Write-host "---- EventID: $EventID - Xpath: `n$xpath"	
			}
		}		
}

# watch in addition for App Event ID 999
$xpath999 = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=999]]
"@

if ($EvtDataPartial) { Write-host " - EvtDataPartial: allow search for partial string in event message '$EvtDataStrings'" }
Write-host " Monitoring $EventlogName for EventID(s): '$Event_ID_list' EventData: '$EvtDataStrings' - CheckInterval $CheckIntInSec sec" -ForegroundColor Green
 $TimeStampStart= Get-Date
while (-not $Trigger) { Start-Sleep $CheckIntInSec;
						$cntr++ ;  write-verbose "Loop# $cntr; $(Get-Date -Format 'yyMMdd-hhmmss') - monitoring EventID(s): '$Event_ID_list' EventData: '$EvtDataStrings'"
						 foreach ($xpath in $xpaths) 
						  { Write-debug "--xPath: $xpath"
							if ($EvtDataPartial) {
								foreach($EvtDataString in $EvtDataStrings) {
									write-verbose "Get-WinEvent -LogName $EventlogName -FilterXPath $xpath  |Where-Object -Property Message -match $EvtDataString"
									$EvtEntry = Get-WinEvent -LogName $EventlogName -FilterXPath $xpath -ErrorAction SilentlyContinue |Where-Object -Property Message -match $EvtDataString |select Message,Id,TimeCreated
									if ($EvtEntry) {break}  
								}
							} else {
								$EvtEntry = Get-WinEvent -LogName $EventlogName -FilterXPath $xpath -MaxEvents $MaxEvents -ErrorAction SilentlyContinue |select Message,Id,TimeCreated;
								}
							
							$EvtEntry999 = ( Get-WinEvent -LogName Application -FilterXPath $xpath999 -MaxEvents $MaxEvents -ErrorAction SilentlyContinue |select Message,Id,TimeCreated )
							$Trigger = ($EvtEntry -or $EvtEntry999)
							if ($Trigger) {
								$TimeStampCurrent=Get-Date; $Dur=($TimeStampCurrent - $TimeStampStart)
								if ($EvtEntry ) {Write-host " EventID '$($EvtEntry.Id)' - EventData '$EvtDataString' found at $($EvtEntry.TimeCreated) - after $($Dur.Days) D $($Dur.Hours) h $($Dur.Minutes) m $($Dur.Seconds) sec / $Dur" -ForegroundColor Yellow
									Write-verbose "$($EvtEntry.Message)"}
								if ($EvtEntry999 ) {Write-host " EventID '$($EvtEntry999.Id)' found at $($EvtEntry999.TimeCreated) - after $($Dur.Days) D $($Dur.Hours) h $($Dur.Minutes) m $($Dur.Seconds) sec / $Dur" -ForegroundColor Yellow
									Write-verbose "$($EvtEntry999.Message)"}
								Start-Sleep $WaitTimeInSec
								break }
						  }
					  }
#end region: MAIN section of script ---------------------------------------------------#

<# allow partial EventData search? https://www.reddit.com/r/PowerShell/comments/gksxp3/how_to_generate_a_here_string_dynamically/

Test:
$xpath = @"
 *[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
 [EventID=$EventIDs]]
 [UserData[EventData[ClientAddressLength='$EvtDataStrings']]]
"@
[EventData[Data='$EvtDataStrings']]

#EvtDataStrings : 3221226599 # for decimal -1073740697 / hex 0xc0000467 #  STATUS_FILE_NOT_AVAILABLE # The file is temporarily unavailable.
#EvtDataStrings : 3221225996 # for decimal -1073741300 / hex 0xc000020c #  STATUS_CONNECTION_DISCONNECTED
#EvtDataStrings : 3221225653 # STATUS_IO_TIMEOUT # The specified I/O operation on %hs was not completed before the time-out period expired.

# Test: .\tss_EvtMonPS.ps1 -EventID 1006 -EventlogName  'Microsoft-Windows-SMBServer/Security' -EvtDataStrings 128
$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= 1000]]
[EventID=999]]
"@
#>