<# Name: NCSI_detect_Company.ps1
# last edit:  2017-03-26
# Purpose: Network Diagnostics Script for NLASVC or NCSI issues, troubleshooting yellow exclamation mark on network icon
#          perhaps if you run the script to perform a probe from the machine, the yellow bang may go away.

Usage:
.\NCSI_detect_Company.ps1 [-Capture_Trace on|off|persistent] [-RootDom <string>] [-KnownExtIPAddr <IPaddress>] [-verbose] 

# =======================================================================================
# See https://blogs.technet.microsoft.com/networking/2012/12/20/the-network-connection-status-icon/
# Appendix K: Network Connectivity Status Indicator and Resulting Internet Communication in Windows Vista http://technet.microsoft.com/en-us/library/cc766017(v=WS.10).aspx
# Appendix H: Network Connectivity Status Indicator and Resulting Internet Communication in Windows 7 and Windows Server 2008 R2 http://technet.microsoft.com/en-us/library/ee126135(v=WS.10).aspx
# The network connectivity status incorrectly appears as "Local only" on a Windows Server 2008-based or Windows Vista-based computer that has more than one network adapter http://support.microsoft.com/kb/947041
#
# Resulting Text file may then be sent to IT for analysis
::  Copyright (C) Microsoft. All rights reserved.
::
::  THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
::  ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
::  IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
::  PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
::
#> 

<#
.SYNOPSIS
Network Diagnostics Script for NLASVC or NCSI issues on your system.
The script helps troubleshooting yellow exclamation mark on network icon issues. 
Using parameter 'on' it will also capture network etl trace. Use 'persistent' to capture across next reboot(s).

.DESCRIPTION
Network Diagnostics Script for NLASVC or NCSI issues on your system.
The script helps troubleshooting yellow exclamation mark on network icon issues. 
You can modify the section ## customization section of script ## for your needs, but all parameters are optional.
NLA and NCSI Operational Eventlogs will be collected. 

Usage:
.\NCSI_detect_Company.ps1 [-Capture_Trace on|off|persistent] [-RootDom <string>] [-KnownExtIPAddr <IPaddress>] [-verbose] 

.EXAMPLE
.\NCSI_detect_Company.ps1 -RootDom microsoft.com -KnownExtIPAddr 23.96.52.53
.\NCSI_detect_Company.ps1 microsoft.com 23.96.52.53 -verbose
Following command will enable Network Tracing
.\NCSI_detect_Company.ps1 -Capture_Trace on

#>

Param(
	[ValidateSet("off","on","persistent")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Want to capture trace, on|off|persistent')]
	[string]$Capture_Trace = "off"
,
	[Parameter(Mandatory=$False,Position=1,HelpMessage='Input your DNS root domain, i.e.  corpintra.net')]
	[string]$RootDom = "microsoft.com"
,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Input your known external IP Addr for DNS root domain corpintra.net ')]
	[IPAddress]$KnownExtIPAddr = "23.96.52.53"
	)
	
	
$ScriptVersion ="1.9"
$startscript = Get-Date # Capture Script start time

switch($Capture_Trace)
	{
	"off"			{$Capture_Trace="off"; $cap_persistent="no"}
	"on"			{$Capture_Trace="on";  $cap_persistent="persistent=no"}
	"persistent"	{$Capture_Trace="on";  $cap_persistent="persistent=yes"}
	}	

if (( -NOT $RootDom) -or ( -NOT $KnownExtIPAddr))  # use the following paramter if script is run without optional parameters [-RootDom <string>] [-KnownExtIPAddr <IPaddress>]
{
###############################################################################
## customization section of script  
# All optional: # actual setting	 # Example for your config	| Example for Microsoft Company
# ------------- = ------------------ #------------------------- | ------------------------------
$RootDom 		= "microsoft.com" 	 # "corpintra.net" 			| "microsoft.com"
# Known external IP Addr for $RootDom - you may use NSLOOKUP to check the external IP-address for external RootDom.com
$KnownExtIPAddr = "23.96.52.53" 	 # "141.113.97.105" 		| "23.96.52.53"
}
$subDom1    	= "corp" 			 # "subDom1" 				| "corp"
$subDom2    	= "europe"			 # "subDom2"					| "europe" 
$ProbeDom		= "dns.msftncsi.com" # "ProbeDom" 				| "dns.msftncsi.com" # "DnsProbeHost"
$companyName    = "Microsoft" 		 # "companyN" 				| "Microsoft"  
$emailUserName  = ""				 # "Admin1@companyN.com"	| ""
$SmtpServerName = "" 				 # "outlook.office365.com"	| ""
# Number of ping attempts before continuing, the less the faster
$pingcount 		= 1					 # 1 to 4	# number of Ping requests to send per IP - Default 4
[bool]$PingExternalIPs= 1			 # 1 or 0 	# whether to PING external IP adresses
[bool]$ListAllInstalledPrograms = 1	 # 1 or 0 	# To get overview of installed programs, possibly known issues
[bool]$Collect_Evt=1				 # 1 or 0 	# To collect 
[bool]$Collect_PSR=1				 # 1 or 0 	# To collect PSR ProblemStepRecorder Screenshot Recording
# Resulting Logfile Name:
# $Logfile = $env:userprofile + "\Desktop\" + $companyName + "_network_" + $env:computername + "_" + $startscript.ToString('yyyyMMdd_HHmm') + ".log"
$Logfile = $env:USERDNSDOMAIN + "_" + $env:computername + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_NCSI.log"
$LogDebugfile = $env:computername + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_Debug.log"
###############################################################################
$Debug=$True

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
$global:DebugOutLog = Join-Path $pwd.path $LogDebugfile  #"$env:computername_$([Guid]::NewGuid().ToString(`"n`")).txt"
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber



# Note: Trying to Start this Win32_Product task early while working on pings
$ListInstalledPrograms = Start-Job -scriptblock {Get-WmiObject -Class Win32_Product | sort-object name | Format-Table Name, Version, InstallDate}

# Preference variable to suppress PS progress bar
# Output looks like: parent = -1 id =0 act Loading Active Directoy module...
$ProgressPreference = 'SilentlyContinue'

$UsrName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
#$computername = $env:computername
#$DnsDom = $env:UserDnsDOMAIN

### Supporting Funtions 
Function LogWrite {
    Param ([string]$logstring, [switch]$verbose, [switch]$error)
    if ($verbose) { #write only to Logfile
		Add-Content $Logfile -value $logstring 
    } elseif ($error) {
		Add-Content $Logfile -value $logstring -PassThru | Write-Host -ForegroundColor red
    } else {
        Add-content $Logfile -value $logstring -PassThru
    }
}

# Function Zip-Files( $zipfilename, $sourcedir )
Function Zip-Files(
        [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$false)]
        [string] $zipfilename,
        [Parameter(Position=1, Mandatory=$true, ValueFromPipeline=$false)]
        [string] $sourcedir,
        [Parameter(Position=2, Mandatory=$false, ValueFromPipeline=$false)]
        [bool] $overwrite)
{
	if ($PSVersionTable.PSVersion.Major -le 2) 
	{ Write-Output "Compression not supported for this PS version: $($PSVersionTable.PSVersion.Major)"}
	else {
		Add-Type -Assembly System.IO.Compression.FileSystem
		$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
		if ($overwrite -eq $true ) { if (Test-Path $zipfilename) { Remove-Item $zipfilename } }
		[System.IO.Compression.ZipFile]::CreateFromDirectory($sourcedir, $zipfilename, $compressionLevel, $false)
	}
}


# Function get-PSversion 
Function get-PSversion {
	$psVersion = $PSVersionTable.PSVersion  
    If($psVersion)  
    { 
        #PowerShell Version Mapping 
        $psVersionMappings = @() 
        $psVersionMappings += New-Object PSObject -Property @{Name='5.1.14393.0';FriendlyName='Windows PowerShell 5.1 Preview';ApplicableOS='Windows 10 Anniversary Update'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.1.14300.1000';FriendlyName='Windows PowerShell 5.1 Preview';ApplicableOS='Windows Server 2016 Technical Preview 5'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.494';FriendlyName='Windows PowerShell 5 RTM';ApplicableOS='Windows 10 1511 + KB3172985 1607'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.122';FriendlyName='Windows PowerShell 5 RTM';ApplicableOS='Windows 10 1511 + KB3140743 1603'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.117';FriendlyName='Windows PowerShell 5 RTM 1602';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8.1, and Windows 7 SP1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.63';FriendlyName='Windows PowerShell 5 RTM';ApplicableOS='Windows 10 1511 + KB3135173 1602'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.51';FriendlyName='Windows PowerShell 5 RTM 1512';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8.1, and Windows 7 SP1'}  
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10514.6';FriendlyName='Windows PowerShell 5 Production Preview 1508';ApplicableOS='Windows Server 2012 R2'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10018.0';FriendlyName='Windows PowerShell 5 Preview 1502';ApplicableOS='Windows Server 2012 R2'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.9883.0';FriendlyName='Windows PowerShell 5 Preview November 2014';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows 8.1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='4.0';FriendlyName='Windows PowerShell 4 RTM';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8.1, and Windows 7 SP1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='3.0';FriendlyName='Windows PowerShell 3 RTM';ApplicableOS='Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8, and Windows 7 SP1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='2.0';FriendlyName='Windows PowerShell 2 RTM';ApplicableOS='Windows Server 2008 R2 SP1 and Windows 7'}    
        foreach ($psVersionMapping in $psVersionMappings) 
        { 
            If($psVersion -ge $psVersionMapping.Name) { 
                @{CurrentVersion=$psVersion;FriendlyName=$psVersionMapping.FriendlyName;ApplicableOS=$psVersionMapping.ApplicableOS}  
                Break  
            }   
        } 
    } 
    Else{ 
        @{CurrentVersion='1.0';FriendlyName='Windows PowerShell 1 RTM';ApplicableOS='Windows Server 2008, Windows Server 2003, Windows Vista, Windows XP'} 
    }	
}

# Function New-WebClient
function New-WebClient
{
    $wc = New-Object Net.WebClient
 
    $wc.UseDefaultCredentials = $true
    $wc.Proxy.Credentials = $wc.Credentials
 
    $wc.Encoding = [System.Text.Encoding]::UTF8
    $wc.CachePolicy = New-Object System.Net.Cache.HttpRequestCachePolicy([System.Net.Cache.HttpRequestCacheLevel]::NoCacheNoStore)
 
    Write-Output $wc
}
$Global:wc = New-WebClient

# WriteTo-StdOut function
# ---------------------
#Author:
#	pcreehan@microsoft.com
#Last Modified:
#	6/16/2011
#Description:
#	This function is dual purposed. When the $Debug variable is set to $true ("debug mode"), it outputs 
#	pipeline input to the $Host, when $Debug is $false or $null ("normal mode"), then it writes the input 
#	to the stdout.log file.
#Arguments:
#	$ObjectToAdd -	Object to add to the output along with any piped in objects
# 	$ShortFormat -	This switch determines whether piped in objects are separated with line breaks or spaces
#	$IsError - 			In debug mode, it will output in Red, in normal mode, has no effect.
#	$Color - 			Sets the Foreground color of the console output. Ignored in normal (not debug) mode.
# 	$DebugOnly - 	Will not write to stdout.log in normal mode.
#	$PassThru - 	Returns the objects passed in as a string. When combined with $DebugOnly, 
#						useful for capturing data that you intend to write to a file
# 	$InvokeInfo -	[System.Management.Automation.InvocationInfo] You can pass in your own invoke info
#						so that script names, resolve correctly. Useful for wrapping functions in a utility .ps1 file
# 	$AdditionaFileName - Write to both stdout output and to an additional log filename
#
#Aliases:
#	Output-Trace
#	Trace
if($null -eq $global:m_WriteCriticalSection) {$global:m_WriteCriticalSection = New-Object System.Object}
function WriteTo-StdOut
{
	param (
		$ObjectToAdd,
		[switch]$ShortFormat,
		[switch]$IsError,
		$Color,
		[switch]$DebugOnly,
		[switch]$PassThru,
		[System.Management.Automation.InvocationInfo] $InvokeInfo = $MyInvocation,
		[string]$AdditionalFileName = $null,
		[switch]$noHeader)
	BEGIN
	{
		$WhatToWrite = @()
		if ($ObjectToAdd -ne  $null)
		{
			$WhatToWrite  += $ObjectToAdd
		} 
		if(($Debug) -and ($Host.Name -ne "Default Host") -and ($Host.Name -ne "Default MSH Host"))
		{
			if($Color -eq $null)
			{
				$Color = $Host.UI.RawUI.ForegroundColor
			}
			elseif($Color -isnot [ConsoleColor])
			{
				$Color = [Enum]::Parse([ConsoleColor],$Color)
			}
			$scriptName = [System.IO.Path]::GetFileName($InvokeInfo.ScriptName)
		}
		$ShortFormat = $ShortFormat -or $global:ForceShortFormat
	}
	PROCESS
	{
		if ($_ -ne $null)
		{
			if ($_.GetType().Name -ne "FormatEndData") 
			{
				$WhatToWrite += $_ | Out-String 
			}
			else 
			{
				$WhatToWrite = "Object not correctly formatted. The object of type Microsoft.PowerShell.Commands.Internal.Format.FormatEntryData is not valid or not in the correct sequence."
			}
		}
	}
	END
	{
		if($ShortFormat)
		{
			$separator = " "
		}
		else
		{
			$separator = "`r`n"
		}
		$WhatToWrite = [string]::Join($separator,$WhatToWrite)
		while($WhatToWrite.EndsWith("`r`n"))
		{
			$WhatToWrite = $WhatToWrite.Substring(0,$WhatToWrite.Length-2)
		}
		if(($Debug) -and ($Host.Name -ne "Default Host") -and ($Host.Name -ne "Default MSH Host"))
		{
			$output = "[$([DateTime]::Now.ToString(`"s`"))] [$($scriptName):$($MyInvocation.ScriptLineNumber)]: $WhatToWrite"

			if($IsError.Ispresent)
			{
				$Host.UI.WriteErrorLine($output)
			}
			else
			{
				if($Color -eq $null){$Color = $Host.UI.RawUI.ForegroundColor}
				$output | Write-Host -ForegroundColor $Color
			}
			if($global:DebugOutLog -eq $null)
			{
				$global:DebugOutLog = Join-Path $Env:TEMP "$([Guid]::NewGuid().ToString(`"n`")).txt"
			}
			$output | Out-File -FilePath $global:DebugOutLog -Append -Force 
		}
		elseif(-not $DebugOnly)
		{
			[System.Threading.Monitor]::Enter($global:m_WriteCriticalSection)
			
			trap [Exception] 
			{
				WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[Writeto-Stdout]: $WhatToWrite" -InvokeInfo $MyInvocation -SkipWriteToStdout
				continue
			}
			Trap [System.IO.IOException]
			{
				# An exection in this location indicates either that the file is in-use or user do not have permissions. Wait .5 seconds. Try again
				sleep -Milliseconds 500
				WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[Writeto-Stdout]: $WhatToWrite" -InvokeInfo $MyInvocation -SkipWriteToStdout
				continue
			}
			if($ShortFormat)
			{
				if ($NoHeader.IsPresent)
				{
				    $WhatToWrite | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	$WhatToWrite | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
				else
				{
		             "[" + (Get-Date -Format "T") + " " + $ComputerName + " - " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " - " + $InvokeInfo.ScriptLineNumber.ToString().PadLeft(4) + "] $WhatToWrite" | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	"[" + (Get-Date -Format "T") + " " + $ComputerName + " - " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " - " + $InvokeInfo.ScriptLineNumber.ToString().PadLeft(4) + "] $WhatToWrite" | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
			}
			else
			{
				if ($NoHeader.IsPresent)
				{
	                 "`r`n" + $WhatToWrite | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	"`r`n" + $WhatToWrite | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
				else
				{
	                 "`r`n[" + (Get-Date) + " " + $ComputerName + " - From " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " Line: " + $InvokeInfo.ScriptLineNumber + "]`r`n" + $WhatToWrite | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	"`r`n[" + (Get-Date) + " " + $ComputerName + " - From " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " Line: " + $InvokeInfo.ScriptLineNumber + "]`r`n" + $WhatToWrite | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
			}
			[System.Threading.Monitor]::Exit($global:m_WriteCriticalSection)
		}
		if($PassThru)
		{
			return $WhatToWrite
		}
	}
}
Filter WriteTo-ErrorDebugReport
(
	[string] $ScriptErrorText, 
	[System.Management.Automation.ErrorRecord] $ErrorRecord = $null,
	[System.Management.Automation.InvocationInfo] $InvokeInfo = $null,
	[switch] $SkipWriteToStdout
)
{
	trap [Exception] 
	{
		$ExInvokeInfo = $_.Exception.ErrorRecord.InvocationInfo
		if ($ExInvokeInfo -ne $null)
		{
			$line = ($_.Exception.ErrorRecord.InvocationInfo.Line).Trim()
		}
		else
		{
			$Line = ($_.InvocationInfo.Line).Trim()
		}
		if (-not ($SkipWriteToStdout.IsPresent))
		{
			"[WriteTo-ErrorDebugReport] Error: " + $_.Exception.Message + " [" + $Line + "].`r`n" + $_.StackTrace | WriteTo-StdOut
		}
		continue
	}
	if (($ScriptErrorText.Length -eq 0) -and ($ErrorRecord -eq $null)) {$ScriptErrorText=$_}
	if (($ErrorRecord -ne $null) -and ($InvokeInfo -eq $null))
	{
		if ($ErrorRecord.InvocationInfo -ne $null)
		{
			$InvokeInfo = $ErrorRecord.InvocationInfo
		}
		elseif ($ErrorRecord.Exception.ErrorRecord.InvocationInfo -ne $null)
		{
			$InvokeInfo = $ErrorRecord.Exception.ErrorRecord.InvocationInfo
		}
		if ($InvokeInfo -eq $null)
		{			
			$InvokeInfo = $MyInvocation
		}
	}
	elseif ($InvokeInfo -eq $null)
	{
		$InvokeInfo = $MyInvocation
	}
	$Error_Summary = New-Object PSObject
	if (($InvokeInfo.ScriptName -ne $null) -and ($InvokeInfo.ScriptName.Length -gt 0))
	{
		$ScriptName = [System.IO.Path]::GetFileName($InvokeInfo.ScriptName)
	}
	elseif (($InvokeInfo.InvocationName -ne $null) -and ($InvokeInfo.InvocationName.Length -gt 1))
	{
		$ScriptName = $InvokeInfo.InvocationName
	}
	elseif ($MyInvocation.ScriptName -ne $null)
	{
		$ScriptName = [System.IO.Path]::GetFileName($MyInvocation.ScriptName)
	}
	$Error_Summary_TXT = @()
	if (-not ([string]::IsNullOrEmpty($ScriptName)))
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Script" -Value $ScriptName 
	}
	if ($InvokeInfo.Line -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Command" -Value ($InvokeInfo.Line).Trim()
		$Error_Summary_TXT += "Command: [" + ($InvokeInfo.Line).Trim() + "]"
	}
	elseif ($InvokeInfo.MyCommand -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Command" -Value $InvokeInfo.MyCommand.Name
		$Error_Summary_TXT += "Command: [" + $InvokeInfo.MyCommand.Name + "]"
	}
	if ($InvokeInfo.ScriptLineNumber -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Line Number" -Value $InvokeInfo.ScriptLineNumber
	}
	if ($InvokeInfo.OffsetInLine -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Column  Number" -Value $InvokeInfo.OffsetInLine
	}
	if (-not ([string]::IsNullOrEmpty($ScriptErrorText)))
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Additional Info" -Value $ScriptErrorText
	}
	if ($ErrorRecord.Exception.Message -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Error Text" -Value $ErrorRecord.Exception.Message
		$Error_Summary_TXT += "Error Text: " + $ErrorRecord.Exception.Message
	}
	if($ErrorRecord.ScriptStackTrace -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Stack Trace" -Value $ErrorRecord.ScriptStackTrace
	}
	$Error_Summary | Add-Member -MemberType NoteProperty -Name "Custom Error" -Value "Yes"
	if ($ScriptName.Length -gt 0)
	{
		$ScriptDisplay = "[$ScriptName]"
	}
	$Error_Summary | ConvertTo-Xml | update-diagreport -id ("ScriptError_" + (Get-Random)) -name "Script Error $ScriptDisplay" -verbosity "Debug"
	if (-not ($SkipWriteToStdout.IsPresent))
	{
		"[WriteTo-ErrorDebugReport] An error was logged to Debug Report: " + [string]::Join(" / ", $Error_Summary_TXT) | WriteTo-StdOut -InvokeInfo $InvokeInfo -ShortFormat -IsError
	}
	$Error_Summary | fl * | Out-String | WriteTo-StdOut -DebugOnly -IsError
}
 
# Function: Validation of DNS request
Function validatedns([string]$dnsrequest, [IPAddress]$knownip) {
    try {
    $addresslist = [Net.DNS]::GetHostEntry($dnsrequest)
    }
    catch {
        LogWrite "DNS request failed" -error
    }
    foreach ($address in $addresslist) {
        if ($address.addresslist -eq $knownip) {
            LogWrite "DNS request to $dnsrequest matched known IP: $($knownip.ToString())" -PassThru | Write-Host  -ForegroundColor green
        } Else {
            LogWrite "DNS request to $dnsrequest did not match known IP: $($knownip.ToString())" -error
        }
    }
}

# Simplified ping Function using Powershell Test-Connection
Function ping($target) {
 # Test-Connection - Sends ICMP echo request packets ("pings") to one or more computers.
 $test = Test-Connection -ComputerName $target -q -count $pingcount 
 if ($test) {
  LogWrite "Ping to $target is successful" -PassThru | Write-Host  -ForegroundColor green
 } Else {
  LogWrite "Error: Ping to $target failed" -error
 }
}

# Test DNS Settings
Function dnstest($domainname) {
 try {
  $addresslist = [Net.DNS]::GetHostEntry($domainname)
  LogWrite "____DNS list of addresses for $domainname"

  foreach ($ip in $addresslist.AddressList.Ipaddresstostring) {
   ping($ip)
  }
        LogWrite
 }
 catch {
  LogWrite "DNS lookup failed for $domainname" -error
        LogWrite
 }
}


#### main ####
LogWrite "Network Tracing is: $Capture_Trace - Persistent: $cap_persistent " 
LogWrite "====================================================================="
LogWrite "Date of test:	$($startscript.ToString('F'))"
LogWrite "Computer: 	$env:COMPUTERNAME  - by User: $UsrName"
LogWrite "DNS Domain: 	$env:USERDNSDOMAIN "

#Capture computer information
#OS version, WINS version
$windowsversion = [System.Environment]::OSVersion.Version.ToString()
LogWrite "Windows Version: $windowsversion"

#$PSversion = Get-Host | Select-Object Version 
#$PSversion = get-PSversion

## output customization section
LogWrite " companyName    : $companyName "  
LogWrite " RootDom        : $RootDom " 
LogWrite " KnownExtIPAddr : $KnownExtIPAddr " 
LogWrite " subDom1        : $subDom1 " 	
LogWrite " subDom2        : $subDom2 " 	
LogWrite " ProbeDom       : $ProbeDom " 
LogWrite " PingCount      : $pingcount "
LogWrite " Capture_Trace  : $Capture_Trace " 
LogWrite "Powershell version: "
get-PSversion 
LogWrite "====================================================================="

### Start Collecting PSR screenshots
if ($Collect_PSR=1) { 
	LogWrite "$(Get-Date -UFormat "%R:%S") === Starting PSR screenshots ================================"
	LogWrite  ( cmd /c START psr.exe /start /output %computername%_psr_Recording.zip /gui 1 /sc 1  2>&1 )
	}
	
### Start collect network trace
if ($Capture_Trace -ieq 'on') {
	LogWrite "$(Get-Date -UFormat "%R:%S") === start network trace ===============================" 
	# $cap_persistent ="persistent=no"
	if ($bn -ge 7600) {  # > Windows 7
	 if ($bn -le 9600) { # < Windows 8.1
	  LogWrite  ( netsh trace start capture=yes $($cap_persistent) scenario=InternetClient,nid_wpp overwrite=yes maxsize=512 tracefile=_$($env:computername)_trace.etl provider="Microsoft-Windows-WinHttp" keywords=0xffffffffffffffff level=0xff provider="Microsoft-Windows-WebIO" keywords=0xffffffffffffffff level=0xff 2>&1 ) }
	 else {	# Windows 10+
	  LogWrite  ( netsh trace start capture=yes $($cap_persistent) InternetClient_dbg,nid_wpp overwrite=yes maxsize=512 tracefile=_$($env:computername)_trace.etl provider="Microsoft-Windows-WinHttp" keywords=0xffffffffffffffff level=0xff provider="Microsoft-Windows-WebIO" keywords=0xffffffffffffffff level=0xff 2>&1 ) }
	}
}

# $winsversion = (Get-ItemProperty 'HKLM:\SOFTWARE\$companyName Versions\WINS\Version').versionnumber + '.' + (Get-ItemProperty 'HKLM:\SOFTWARE\$companyName Versions\WINS\Version').pointnumber
# LogWrite "$companyName WINS version: $winsversion"

LogWrite 
LogWrite "$(Get-Date -UFormat "%R:%S") === Status of NLA service =================================="
 #$network_awareness = Get-Service "network location awareness" | Select-Object status, name, displayname, starttype | Format-List
 $network_awareness = Get-Service "network location awareness" | Format-List
 LogWrite ($network_awareness | Out-String)

### Capture Windows Firewall Settings
 $win_firewall = netsh advfirewall monitor show firewall
 if ($win_firewall | Select-String "make sure that the service is running") {
  LogWrite "Windows Firewall is correctly not enabled"
 } Else {
  LogWrite "$(Get-Date -UFormat "%R:%S") === Windows Firewall Settings ============================="
  LogWrite "Windows Firewall Settings"
  LogWrite ($win_firewall | Select-String Categories -Context 0,4 | Out-String)
  LogWrite ($win_firewall | Select-String Profile -Context 0,4 | Out-String)
 }

# Good response example:
# Categories:
# BootTimeRuleCategory                  McAfee Host Intrusion Prevention Firewall
# FirewallRuleCategory                  McAfee Host Intrusion Prevention Firewall
# StealthRuleCategory                   McAfee Host Intrusion Prevention Firewall
# ConSecRuleRuleCategory                Windows Firewall
# 
# Domain Profile Settings:
# ------------------------------------------
# State                                 OFF


### Capture network adapter settings
LogWrite "$(Get-Date -UFormat "%R:%S") === Network adapter Settings ================================"
$addresses = Get-WmiObject -Class win32_networkadapterconfiguration 
$gwaddresses = $addresses | ForEach-Object {if ($_.defaultipgateway) {$_}}
LogWrite ($gwaddresses | Out-String)

### DHCP Settings including lease time
LogWrite "$(Get-Date -UFormat "%R:%S") === DHCP adapters ==========================================="
$dhcpadapters = $addresses | ForEach-Object {if ($_.dhcpenabled -And $_.ipaddress) {$_}}

# Convert CIM_Datetime to Date
# https://social.technet.microsoft.com/Forums/scriptcenter/en-US/5e73e100-f955-45e1-b7b2-98afdd3e3aa9/powershell-convert-stringvalue-like-20120626141935730000000-to-datetime?forum=ITCG
foreach ($dhcpadapter in $dhcpadapters) {
 $dhcpexpires = [Management.ManagementDateTimeConverter]::ToDateTime($dhcpadapter.DHCPLeaseExpires)
 $dhcpobtained = [Management.ManagementDateTimeConverter]::ToDateTime($dhcpadapter.DHCPLeaseObtained)
 $ipaddress = $dhcpadapter.ipaddress
 LogWrite "DHCP of $ipaddress Expires: $($dhcpexpires.ToString('F'))"
 LogWrite "DHCP of $ipaddress Obtained: $($dhcpobtained.ToString('F'))"
    LogWrite 
}

### Test network stack
LogWrite "$(Get-Date -UFormat "%R:%S") === Network stack ==========================================="
LogWrite "__Testing network stack, Ping 127.0.0.1"
ping("127.0.0.1")

# Ping default Gateway
# Can't ping vpn default gateway
LogWrite "__runnning PING tests for default Gateway"
foreach($address in $gwaddresses) {ping($address.defaultipgateway)}

# Test IP connectivity of Internet Sites
if ($PingExternalIPs) {
	LogWrite "__runnning PING tests for external IP-adresses and Internet Sites"
	ping("8.8.8.8")
	ping("8.8.4.4")
	ping("google.com")

	LogWrite "__runnning DNS tests for configured $RootDom and external domain names"
	dnstest("$RootDom")
	dnstest("microsoft.com")
	dnstest("portal.office.com")
	dnstest("google.com")
	dnstest("scribd.com")
	LogWrite "__runnning DNS tests for Standard Microsoft dns.msftncsi.com and www.msftncsi.com"
	dnstest("dns.msftncsi.com")
	dnstest("www.msftncsi.com")
}

LogWrite "__runnning PING tests for script configured sub domain names '$subDom2.$subDom1.$RootDom' "
if ($subDom1 -ne "") {ping("$subDom1.$RootDom")
 if ($subDom2 -ne "") {ping("$subDom2.$subDom1.$RootDom")}}
if ($ProbeDom -ne "") {ping("$ProbeDom")}


LogWrite
LogWrite "__Validate company DNS for: $RootDom for known IP address: $KnownExtIPAddr"
validatedns "$RootDom" "$KnownExtIPAddr"
LogWrite

# focus on NCSI settings which are used to determine Microsoft Windows
# Yellow triangle for network issues

LogWrite "$(Get-Date -UFormat "%R:%S") === NCSI tests =============================================="
LogWrite "__Now Duplicating Windows NCSI yellow triangle tests"
LogWrite


### Capture workstation settings
# Read registry entries for NCSI Settings
$NCSIsettings = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\services\NlaSvc\Parameters\Internet
$SWncsisettings = Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator

# Read IP address
$addresses = Get-WmiObject -Class win32_networkadapterconfiguration 
$gwaddresses = $addresses | ForEach-Object {if ($_.defaultipgateway) {$_}}

# Global Variables
$activeWebHost = $NCSIsettings.ActiveWebProbeHost
$activeWebPath = $NCSIsettings.ActiveWebProbePath
$knownWebContent = $NCSIsettings.ActiveWebProbeContent
$activeProbe_enabled = $NCSIsettings.EnableActiveProbing
$DnsProbeHost = $NCSIsettings.ActiveDnsProbeHost
$DnsProbeContent = $NCSIsettings.ActiveDnsProbeContent


######## Test 1 Function
# Check EnableActiveProbing=1 Registry Setting
Function ActiveProbe_isEnabled($activeprobe) {
 if ($activeprobe) {
		$result = "Yes" 
        return $result 
 }
 Else {
		$result = "Test1 Error: EnableActiveProbing setting is disabled. ActiveProbe Setting: $activeprobe"
        return $result
 }
}

######## Test 2 Function (used in Test 2 and 4)
# Check DNS query against known IP address
Function test_DNS([string]$hostname, [IPAddress]$knownip) {
    try {
		$addresslist = [Net.DNS]::GetHostEntry($hostname)
    }
    catch {
        $result = "Error: DNS lookup failed for $hostname. IP: $($gwaddresses.ipaddress | Out-String -Stream) DNS: $($gwaddresses.DnsServerSearchOrder | Out-String -Stream)"
        return $result
		return
    }
	if ($knownip) {
		foreach ($address in $addresslist) {
          if ($address.addresslist -eq $knownip) {
                    $result = "Success: KnownIP '$knownip' "
					return $result 
          } Else {
			$result = "Error: DNS request to $hostname at $($address.addresslist.IPaddresstostring) did not match known IP: $($knownip.ToString()) PC IP: $($gwaddresses.ipaddress | Out-String -Stream) DNS: $($gwaddresses.DnsServerSearchOrder | Out-String -Stream)"
			return $result
			}
		}
	} Else {
        $result = "Success: HostName '$hostname' "
		return $result
	}
}

######## Test 3 and Test 4 Function
# Check Web probe for known content
Function test_WebProbe ([string]$webserver, [string]$path, [string]$ExpectedContent) {
 $uri = "http://" + $webserver + '/' + $path
 if ($bn -le 9200) { # < Windows 8.1
	$webrequest = (New-Object Net.WebClient).DownloadString($uri)
	$ActualContent=$webrequest
	}
 else {	#Invoke-WebRequest cmdlet is introduced in Windows PowerShell 3.0. 
	$webrequest = Invoke-WebRequest -Uri $uri
	$ActualContent=$webrequest.content
	}
 
 if ($ActualContent -eq $ExpectedContent) {
    $result = "Success: $($ActualContent)"
  return $result
 } Else {
     $result = "Error: Web Request content, ""$($webrequest.content)"" does not match known content: ""$ExpectedContent"" IP: $($gwaddresses.ipaddress | Out-String -Stream) DNS: $($gwaddresses.DnsServerSearchOrder | Out-String -Stream)"
        return $result
 }
}

# Now actually performing Test 1-5 Functions
### Test 1
# Check IP address for ping to return where failures occur
# Check to see if computer is set to actively probe NCSI
    LogWrite "__Test 1: Check EnableActiveProbing Setting enabled"
	$result1 = ActiveProbe_isEnabled($activeProbe_enabled)
 	LogWrite "	Result1: '$result1' " -PassThru | Write-Host  -ForegroundColor green

### Test 2
# Check DNS against www.msftncsi.com
if ($result1 -eq "Yes") {
	# first step NCSI performs is a DNS query for www.msftncsi.com
	LogWrite "__Test 2: Check DNS against WebProbeHost '$activeWebHost' "
    $result2 = test_DNS($activeWebHost) 
	LogWrite "	Result2: '$result2' " -PassThru | Write-Host  -ForegroundColor green
}

### Test 3 www.msftncsi.com (Win10: www.msftconnecttest.com)
# Check Web probe for known Web content
# "second step is and HTTP get request for http://www.msftncsi.com/ncsi.txt"
if ($result2 -match "Success") {
	LogWrite "__Test 3: Check Web probe for active http://'$activeWebHost'/'$activeWebPath' known WebContent: '$knownWebContent' "
    $result3 = test_WebProbe $activeWebHost $activeWebPath $knownWebContent
	LogWrite "	Result3: '$result3' " -PassThru | Write-Host  -ForegroundColor green
}

### Test 4 -Check DNS query for '$DnsProbeHost' 
if ($result3 -match "Success") {
	# "Last it will perform a DNS query for dns.msftncsi.com."
	LogWrite "__Test 4: Check DNS query against DnsProbeHost '$DnsProbeHost' '$DnsProbeContent' "
    $result4 = test_DNS $DnsProbeHost $DnsProbeContent
	LogWrite "	Result4: '$result4' " -PassThru | Write-Host  -ForegroundColor green
}

LogWrite "***NCSI Results: '$result4' ***" -PassThru | Write-Host  -ForegroundColor green
LogWrite

### Test 5 - DNS lookup for ActiveWebProbeHost:
LogWrite "__DNS lookup for list in addresses for ActiveWebProbeHost"
LogWrite "__Test 5 - DNS lookup for ActiveWebProbeHost: '$($NCSIsettings.ActiveWebProbeHost)' " 
	dnstest($NCSIsettings.ActiveWebProbeHost)

### Test 6 - DNS lookup for Microst WebProbeHost:
LogWrite "__Test 6 - Web probe for 'www.msftconnecttest.com' and 'www.msftncsi.com' " 
LogWrite "___Check Web probe for http://'www.msftconnecttest.com'/'connecttest.txt' known WebContent: 'Microsoft Connect Test' "
	$result6a = test_WebProbe www.msftconnecttest.com connecttest.txt 'Microsoft Connect Test'
LogWrite "	Result6a: '$result6a'" -PassThru | Write-Host  -ForegroundColor green
LogWrite "___Check Web probe for http://'www.msftncsi.com'/'ncsi.txt' known WebContent: 'Microsoft NCSI' "
	$result6b = test_WebProbe www.msftncsi.com ncsi.txt 'Microsoft NCSI'
LogWrite "	Result6b: '$result6b'" -PassThru | Write-Host  -ForegroundColor green

#### Write out long parts to the log file
LogWrite -verbose
LogWrite "$(Get-Date -UFormat "%R:%S") === NCSI settings ============================================" -verbose
LogWrite "Output of computer Registry details" -verbose
LogWrite "__Output of NCSI NLA settings" -verbose
LogWrite ($NCSIsettings | Out-String -Width 1024) -verbose
LogWrite "__Output of NCSI Software settings" -verbose
LogWrite ($SWncsisettings | Out-String -Width 1024) -verbose

LogWrite "__Output of GW adresses" -verbose
LogWrite ($gwaddresses | format-list * | Out-String) -verbose

### Add a list of installed programs
if ( $ListAllInstalledPrograms) {
 # This adds an additional 30 seconds to the script
 LogWrite " "
 Write-Verbose "ListAllInstalledPrograms: $ListAllInstalledPrograms"
 # Loop through a message until WMI call started at the beginning finishes
 LogWrite "$(Get-Date -UFormat "%R:%S") === Installed Programs =====================================" -verbose
 LogWrite "Collecting all installed programs" | Write-Host -NoNewLine
 While ($ListInstalledPrograms.JobStateInfo.State -ne "Completed") {
	Write-Host '.' -nonewline
	Start-Sleep -milliseconds 500
 }
 LogWrite (Receive-Job -job $ListInstalledPrograms | Out-String -Width 1024)  -verbose
 #|Out-file $Logfile -Append -Encoding String -Width 1024
 Write-verbose "ListAllInstalledPrograms_Done " 
}
	
### Add-content $Logfile -value $win_firewall #long format for file to LogFile
LogWrite "$(Get-Date -UFormat "%R:%S") === Firewall ================================================" -verbose
LogWrite "___Output of Win Firewall details" -verbose
LogWrite ($win_firewall | Out-String) -verbose

### Add-content Registry Settings to LogFile
LogWrite "$(Get-Date -UFormat "%R:%S") === Registry ================================================" -verbose
LogWrite "___Output of Registry System NlaSvc\Parameters\Internet" -verbose
$RegNLA  = reg query HKLM\System\CurrentControlSet\services\NlaSvc\Parameters\Internet /s
LogWrite ($RegNLA | Out-String) -verbose
LogWrite "___Output of Registry Software NetworkConnectivityStatusIndicator" -verbose
$RegNCSI = reg query HKLM\Software\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator /s
LogWrite ($RegNCSI | Out-String) -verbose

### Stop Collecting PSR screenshots
if ($Collect_PSR=1) { 
	LogWrite "$(Get-Date -UFormat "%R:%S") === Stopping PSR screenshots================================="
	LogWrite  ( psr.exe /stop  2>&1 )
	}

### Collect network trace
if ($Capture_Trace -ieq 'on') {
	LogWrite
	LogWrite "$(Get-Date -UFormat "%R:%S") === end network trace =======================================" #-NewLine
	LogWrite " Generating trace data collection... please be patient..."
	LogWrite  ( NETSH TRACE STOP 2>&1 )
	if ($cap_persistent -ieq "persistent=yes") {LogWrite "NETSH Trace capture is enabled across reboot! To stop tracing session after reboot run: 'NETSH TRACE STOP'"}
	}

### Collect Network Location Awareness, NCSI, System and Application EventLog
if ($Collect_Evt) {
	LogWrite
	LogWrite "$(Get-Date -UFormat "%R:%S") === Network Location Awareness EventLogs ====================" #-verbose
	LogWrite "_Collecting Network Location Awareness EventLog"
	$OutEvtNlaSvc= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_NlaSvc-Operational.evtx"
	$OutEvtNCSI= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_NCSI-Operational.evtx"
	$OutEvtSystem= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_System.evtx"
	$OutEvtApp= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_Application.evtx"	
	wevtutil export-log Microsoft-Windows-NlaSvc/Operational $OutEvtNlaSvc
	wevtutil export-log Microsoft-Windows-NCSI/Operational $OutEvtNCSI
	wevtutil export-log System $OutEvtSystem
	wevtutil export-log Application $OutEvtApp
	}
	
LogWrite " "
LogWrite "$(Get-Date -UFormat "%R:%S") === More Information ========================================" 
LogWrite "For More Information:"
LogWrite "See https://blogs.technet.microsoft.com/networking/2012/12/20/the-network-connection-status-icon/"
LogWrite "and "
LogWrite "Appendix H: Network Connectivity Status Indicator and Resulting Internet Communication in Windows 7 and Windows Server 2008 R2 http://technet.microsoft.com/en-us/library/ee126135(v=WS.10).aspx"
LogWrite " "

$endscript = Get-Date
$script_time = (New-TimeSpan -Start $startscript -End $endscript).seconds
LogWrite "Script v$ScriptVersion Execution duration: $script_time seconds"

### Send email
if ($SmtpServerName -ne "") {
LogWrite "$(Get-Date -UFormat "%R:%S") === Send per Email  =========================================" 
	Send-MailMessage -To $emailUserName -subject "Network Issues" -Body "Here is the report" -Attachments $Logfile -From "$emailUserName" -SmtpServer $SmtpServerName -UseSsl }

### Zip file if PowerShell v3 or higher is installed
if ($PSVersionTable.PSVersion.Major -gt 2) {
	LogWrite "$(Get-Date -UFormat "%R:%S") === Zip Data ================================================" 
	$OutputFileZip = join-path $pwd.path ($env:USERDNSDOMAIN + "_" + $env:ComputerName + "_" +$startscript.ToString('yyyyMMdd_HHmm')+ "_NCSI.zip")
	#$zipdir = join-path $pwd.path ("_NCSI_out") # $env:TEMP
	$zipdir = join-path $env:TEMP ("_NCSI_out") # $env:TEMP
	if (-NOT (Test-Path $zipdir)) {new-item -path $zipdir -type directory |out-null}
	Copy-Item $Logfile $zipdir -Force #-Exclude '*.zip'
	if ($Capture_Trace -ieq 'on') {Move-Item _*trace.* $zipdir -Force}
	if ($Collect_Evt) {Move-Item *_evt_*.* $zipdir -Force}
	if ($Collect_PSR) {Move-Item $env:ComputerName_psr*.* $zipdir -Force}
	Zip-Files -zipfilename $OutputFileZip -sourcedir $zipdir -Verbose -overwrite $true
	Remove-Item $zipdir -Force -Recurse
	Write-host -BackgroundColor Black -ForegroundColor Gray "Logfile zipped to $OutputFileZip"
}
else {
	Write-host -BackgroundColor Black -ForegroundColor Gray "Logfile is here: $Logfile"
}

LogWrite
if ($cap_persistent -ieq "persistent=yes") {LogWrite "NETSH Trace capture is enabled across reboot! To stop tracing session after reboot run: 'NETSH TRACE STOP'" -PassThru | Write-Host  -ForegroundColor green }
LogWrite

#Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force 
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
if ($PSVersionTable.PSVersion.Major -gt 2) { Unblock-File -Path NCSI_detect_Company.ps1 -ErrorAction SilentlyContinue }
 Write-Host -ForegroundColor Gray "... [Info] in case you see any red error messages regarding script signing, open an Admin Powershell CMD and run this command first:
 	 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

 	 " 
LogWrite

#===all done ================================================================
# In addition please collect a SDP report 'Network Diagnostics' to verify the ProxyConfiguration