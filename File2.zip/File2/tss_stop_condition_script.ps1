<# Name: tss_stop_condition_script.ps1 [-Folderpath -TestCondition -PollIntervalInSec] [-BranchCache or BC] [-PortLoc] [-PortDest] [-SvcName] [-ServerName] [-ShareName] [-ProcessName] [-DomainName] 
Purpose: use this PowerShell script in combination with 'TSS Stop:ps1' as a stop trigger for data collection
Examples:
1.  until the system stops listening on local TCP 0.0.0.0:135

:: Purpose:  script to process individual stop condition and then end the 'tss ... ' repro section
::
:: Script input parameters: 
:: 	%1 _Folderpath		- path for output data
:: 	%2 _TestCond		- Name of predefined or custom Test condition, Examples below (BranchCache|BC|Dfs|HTTP|PortDest|PortLoc|Process|RDP|Smb|Svc|WINRM|custom)
:: 	%3 _PollInterval 	- Interval in seconds to check, default is 8 seconds
:: 	%4 _StopFileExists	- Filename for termination condition

#>


<# 
.SYNOPSIS
	Script to process individual stop condition and then end the 'tss .. Stop:ps1:... ' repro section, if a failure happens

.DESCRIPTION
	Script will process individual stop condition, choose from BranchCache|BC|Dfs|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Smb|Svc|WINRM|Share|custom

.PARAMETER Folderpath
	Specify a path for output data, i.e. C:\MS_DATA
	
.PARAMETER TestCondition
	Name of predefined or custom Test condition, Specify one of the predefined test Examples (BranchCache|BC|Dfs|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Smb|Svc|WINRM|Share|custom)
	
.PARAMETER PollIntervalInSec
	Specify an interval in seconds for checks, default is 8 seconds
	
.PARAMETER BranchCache or BC
	Specify a threshold to watch for, BCpercent=120 or BCpercent=180, to be configured in tss_config.cfg
.PARAMETER PortLoc
	Specify a local TCP port number to watch for, if local port is still listening
.PARAMETER PortDest
	Specify a Destination TCP port number to watch for,	if remote system is still listening
.PARAMETER SvcName
	Verify if the service with serviceName is running
.PARAMETER ServerName
	Server Name to be tested, default LocalHost
.PARAMETER ShareName
	SMB Share Name to be tested
.PARAMETER ProcessName
	Process Name to be tested. Verify if the Process is running
.PARAMETER DomainName
	Domain Name to be tested. Verify if 'nltest /DSGETDC:$DomainName' returns result
	
.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "BranchCache" -PollInterval 5
	Example 1: will stop if MaxCacheSizeAsNumberOfBytes exceeds 120% or 180%, or NrOfDatFilesLimit exceeds limit; checks performed in intervals of PollIntervalInSec
	
.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "PortLoc" -PollInterval 8
	Example 1: will stop if local system is no more listening on TCP port 0.0.0.0:135, checks performed in intervals of 8 seconds, default PortLoc=135

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "PortDest" -PollInterval 8 -ServerName "ServerName"
	Example 2: will stop if remote system "ServerName" is no more listening on TCP ports 135 and 445, checks performed in intervals of 8 seconds, default PortDest=135,445

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "SMB" -ServerName "ServerName"
	Example 3: will stop if server is no more listening on TCP port 445, or not pingable
	Same tests are available for HTTP,RDP,WINRM
	
.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Svc" -SvcName "LanmanServer"
	Example 4: will stop if the specified service is not running, default servcie name is LanmanWorkstation

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Share" -ServerName "ServerName" -ShareName "Contoso-Share"
	Example 5: will stop if the specified ShareName on ServerName is not reachable , default ServerName:LocalHost, ShareName:Contoso-Share

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Process" -ProcessName "notepad"
	Example 6: will stop if the specified ProcessName has stopped

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "LDAP" -DomainName "$env:userdomain"
	Example 7: will stop if  'nltest /DSGETDC:$DomainName' fails
	
.LINK
	email waltere
	
#>


param(
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("BranchCache","BC","Dfs","HTTP","LDAP","PortDest","PortLoc","Process","RDP","Svc","SMB","WINRM","Share","custom")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: BranchCache|BC|Dfs|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Smb|Svc|WINRM|Share|custom')]
	[string]$TestCondition = "custom"
	,
	[Int32]$PollIntervalInSec 	= 8,				# repeat test in intervals of x seconds
	[Int32]$ErrorLimit   		= 1,				# stop i fat least x errors happend
	[Int32]$PortLoc 	 		= 135,				# choose a local TCP port number
	[Int32]$BCpercent 	 		= 120,				# for test if Branchcache size breached 120%
	[Int32]$NrOfDatFilesLimit 	= 1024,				# number of maximum Branchcache PeerDistRepub files per folder
	[string]$PortDest,								# choose a remote TCP port number
	[string]$DomainName	 = "$env:userdomain",		# for LDAP test
	[string]$SvcName 	 = "LanmanWorkstation",		# choose a service name
	[string]$ServerName  = "LocalHost",				# for SMB test
	[string]$ShareName   = "Contoso-Share",			# for SMB test
	[string]$ProcessName = "notepad"				# choose a process name without '.exe'
)

$VerDate = "2020.08.03.0"

#region  ::::: Configruation parameters ::::::::::::::::::::::::::::::::::::::::::::::
	[Int32]$TST_ERR_LIMIT 	= $ErrorLimit
	#[Int32[]]$PortDest	= $(135,445)
	if ($PortDest) { $Port_Dest	= $($PortDest.split("/")) }

#endregion ::::: Configruation parameters ::::::::::::::::::::::::::::::::::::::::::::::

$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent

#region  ::::: Functions :::::

# :::::::::: Begin of your own/custom condition logic ::::::::::::::::::::::::::::::::::::::::::::::
function Test_custom {
	Write-Log "What is expected/not expected by now?"
	# Example for SMB:
	$TcpTestStatus = ((Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB -ErrorAction SilentlyContinue).TcpTestSucceeded)
	if ("$TcpTestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName stopped listening on SMB port 445, result: $TcpTestStatus "}
}
# :::::::::: End of your own/custom condition logic   ::::::::::::::::::::::::::::::::::::::::::::::

function Test_AskYN {
	Write-Log "work in progress, waiting for user answer Y/N "
	# loop until the user enters N or E
	do
	{
		Start-Sleep $PollIntervalInSec
		$UserInput = Read-Host 'Do you want to continue [Y|N] or E= end'
		if ($UserInput -match 'n') {Write-Log " ...ending loop per User Input: $UserInput "
									break}
	} until ($UserInput -match 'E')
}

function Test_BCpercent {
	# if MaxCacheSizeAsNumberOfBytes reaches 120% or 180% , checks performed in intervals of 5 minutes
	$BCTestStatus =	& "$ScriptParentPath\tss_BCpercentRule.ps1" -Folderpath $Folderpath -BCpercentNr $BCpercent -NrOfDatFilesLimit $NrOfDatFilesLimit #-EA SilentlyContinue
	if ("$BCTestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "Branch Cache test breached limit $BCpercent % or *.dat $NrOfDatFilesLimit, BCTestStatus result: $BCTestStatus "}
	else { Write-Verbose "$(Get-date -Format G) | Result BCpercentRule: $BCTestStatus -- Script:StopCondFound $Script:StopCondFound -- CurrentActiveCacheSize: $((Get-BCDataCache).CurrentActiveCacheSize)" }
} 
function Test_PortLoc {
	# check if system stops listening on local TCP 0.0.0.0:135
	$Script:StopCondFound = Get-NetTCPConnection -State Listen -LocalPort $PortLoc -LocalAddress 0.0.0.0 -EA SilentlyContinue
} 
function Test_PortDest ($Port, $ServerName) {
	# check if remote system stops listening on TCP port 135
	$TcpTestStatus = Test-Netconnection -ComputerName $ServerName -Port $Port -InformationLevel "Detailed" -EA SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "Test-Netconnection $ServerName failed with result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 

function Test_Share {
	# check if \\server\Share is reachable via SMB ; ToDo: note Test-NetConnection requires PS version ??
	$TestStatus = Test-Path \\$ServerName\$ShareName -ErrorAction SilentlyContinue
	if ("$TestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "\\$ServerName\$ShareName not reachable, result: "; $TestStatus | Out-File $LogFileScript -Append}
} 

function Test_SMB {
	# check if server is reachable via SMB port 445; ToDo: note Test-NetConnection requires PS version ??
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName stopped listening on SMB port 445, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_HTTP {
	# check if server is reachable via HTTP
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort HTTP -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via HTTP, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
}
function Test_LDAP {
	# check for failing 'nltest /DSGETDC:$DomainName'
	$TestStatus = nltest /DSGETDC:$DomainName /LDAPONLY
	if ($LASTEXITCODE -ne 0 ) {$Script:StopCondFound=0; Write-Log "DC in Domain $DomainName is not reachable via /LDAPONLY, result: $TestStatus - LASTEXITCODE: $LASTEXITCODE "; "$($TestStatus)" | Out-File $LogFileScript -Append}
}
function Test_RDP {
	# check if server is reachable via RDP
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort RDP -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via RDP, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_WINRM {
	# check if server is reachable via WINRM
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort WINRM -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via WINRM, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_Svc {
	# check if service status is Running  (not Stopped)
	$SvcStatus = ((Get-Service $SvcName -ErrorAction SilentlyContinue).Status)
	Write-Verbose "SvcStatus $SvcName :	$SvcStatus - Found: $($SvcStatus -eq "Running")"
	$Status = ((Get-Service $SvcName -ErrorAction SilentlyContinue).Status)
	if ($Status -ne "Running" ) {$Script:StopCondFound=0; Write-Log "$SvcName stopped running: $Status "}
} 
function Test_Process {
	# check if Process is running 
	$Script:StopCondFound = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
}

#region  ::::: Helper Functions :::::
function Get-TimeStamp {
	# SYNOPSIS: Returns a timestamp string
	return "$(Get-Date -Format "yyyyMMdd_HHmmss_ffff")"
} # end Get-TimeStamp
function Write-Log {
	# SYNOPSIS: Writes script information to a log file and to the screen when -Verbose is set.
	[CmdletBinding()]param([string]$text, [Switch]$tee = $false, [string]$foreColor = $null, [string]$backColor = "DarkBlue")
	$foreColors = $backColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"
	# check the log file, create if missing
	$isPath = Test-Path $LogFileScript
	if (!$isPath) {
		"TSS_stop_condition_script.ps1 v$VerDate Log started on $ENV:ComputerName - $Script:osVer - $Script:osNameLong " 	| Out-File $LogFileScript -Force
		"Local log file path: $LogFileScript" 														| Out-File $LogFileScript -Append
		"PowerShell version:  $Script:PSver " 														| Out-File $LogFileScript -Append
		"Start time (UTC):    $((Get-Date).ToUniversalTime())" 										| Out-File $LogFileScript -Append
		"Start time (Local):  $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})`n" | Out-File $LogFileScript -Append
	Write-Verbose "$(Get-Date -Format "HH:mm:ss") Local log file path: $LogFileScript"
  }
  # write to log
  "$(Get-date -Format G) | $text" | Out-File $LogFileScript -Append
  # write text verbosely
  Write-Verbose $text
  if ($tee)
  {
    # make sure the foreground color is valid
    if ($foreColors -contains $foreColor -and $foreColor)
    {
      Write-Host -ForegroundColor $foreColor -BackgroundColor $backColor $text
    } else {
      Write-Host $text
    }
  }
} # end Write-Log
#endregion  ::::: Helper Functions :::::
#endregion  ::::: Functions :::::

#region ::::: CONSTANTS AND VARIABLES :::::
#region  ::::: Variables :::::
[string]$LogFileScript=$Folderpath +"\"+ $ENV:ComputerName + "__Stop-Cond-Log_" + $TestCondition + ".txt"
Write-Verbose "LogFileScript: $LogFileScript"
[Int32]$TST_LOOP_CNT=0
[Int32]$TST_ERROR_CNT=0
#endregion  ::::: Variables :::::

# OS version
#[void]( $Script:OSinfo = (Get-CimInstance Win32_OperatingSystem) )
$Script:osVer = (Get-WmiObject win32_operatingsystem).Version
$Script:osNameLong = $Script:osName = (Get-WmiObject win32_operatingsystem).Name
$Script:osMajVer = [System.Environment]::OSVersion.Version.Major
$Script:osMinVer = [System.Environment]::OSVersion.Version.Minor
$Script:osBldVer = [System.Environment]::OSVersion.Version.Build
$Script:PSver = $PSVersionTable.PSVersion.Major

# OS version name
if ($Script:osMajVer -le 5) {
  [string]$Script:osName = "Unsupported"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 0) {
  [string]$Script:osName = "2008"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 1) {
  [string]$Script:osName = "2008R2"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 2) {
  [string]$Script:osName = "2012"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 3) {
  [string]$Script:osName = "2012R2"
 } elseif ($Script:osMajVer -eq 10) {
  [string]$Script:osName = "10"
 }
#endregion ::::: CONSTANTS AND VARIABLES :::::

#region :::::  Main 
Write-Log -tee -foreColor Green "...v$VerDate - running verification for Test Condition: $TestCondition, check interval: $PollIntervalInSec seconds."

# loop iteration until $TST_ERR_LIMIT is reached
do {
	# loop until stop condition is met
	$Script:StopCondFound=1
	do
	{
		if ($TST_LOOP_CNT -ge 1 ) {Start-Sleep $PollIntervalInSec}
		$TST_LOOP_CNT +=1
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		Write-Verbose "LoopCnt: $TST_LOOP_CNT"
		switch($TestCondition)
			{
			"custom"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: custom test condition"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_custom }
			"Share"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-Path \\$ServerName\$ShareName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Share }
			"BranchCache" { if ($TST_LOOP_CNT -le 1) { Unblock-File -Path tss_BCpercentRule.ps1 -EA SilentlyContinue; Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test tss_BCpercentRule.ps1 Branchcache $BCpercent % breach"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_BCpercent }
			"BC"		{ if ($TST_LOOP_CNT -le 1) { Unblock-File -Path tss_BCpercentRule.ps1 -EA SilentlyContinue; Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test tss_BCpercentRule.ps1 Branchcache $BCpercent % breach"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_BCpercent }
			"Dfs"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: tbd"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_AskYN }
			"LDAP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: nltest /DSGETDC:$DomainName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_LDAP }
			"PortDest"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-Netconnection -ComputerName $ServerName -Port $Port_Dest"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							foreach ($Port in $Port_Dest) {Test_PortDest $Port $ServerName} }
			"PortLoc"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-NetTCPConnection -State Listen -LocalPort $Port -LocalAddress 0.0.0.0"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_PortLoc }
			"Process"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-Process -Name $ProcessName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Process }
			"Svc"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-Service $SvcName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Svc }
			"Smb"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_SMB }
			"HTTP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort HTTP"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_HTTP }
			"RDP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort RDP"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_RDP }
			"WINRM"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort WINRM"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_WINRM }
			}
	} until (-NOT $Script:StopCondFound)
	$TST_ERROR_CNT +=1
	Write-Log -tee -foreColor Gray "   Error count: $TST_ERROR_CNT, waiting until count reached limit of: $TST_ERR_LIMIT"
} until ($TST_ERROR_CNT -ge $TST_ERR_LIMIT)

Write-Log -tee -foreColor Red "...v$VerDate - Stop Condition $TestCondition met at: $(Get-Date)"
#endregion :::::  Main 